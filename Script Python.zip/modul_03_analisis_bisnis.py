"""
================================================================
MODUL PYTHON 3: ANALISIS BISNIS PROPERTI
Artha Properti Sejahtera - Data Analyst Learning Path
Level: Menengah | Estimasi: 3 Minggu
================================================================
TOPIK: Sales analysis, marketing ROI, customer segmentation,
       construction tracking, financial metrics, KPI dashboard
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# ─── Palette brand Artha Properti ────
COLORS = {
    'primary': '#1B4F72',
    'green':   '#1E8449',
    'gold':    '#D4AC0D',
    'red':     '#CB4335',
    'grey':    '#BDC3C7',
    'accent':  '#2E86C1',
}
DATA_PATH = "./data/"

# Load data
df_proyek    = pd.read_csv(f"{DATA_PATH}dim_proyek.csv")
df_unit      = pd.read_csv(f"{DATA_PATH}dim_unit.csv")
df_pelanggan = pd.read_csv(f"{DATA_PATH}dim_pelanggan.csv")
df_penjualan = pd.read_csv(f"{DATA_PATH}fact_penjualan.csv",
                            parse_dates=['tanggal_sp','tanggal_akad'])
df_campaign  = pd.read_csv(f"{DATA_PATH}fact_marketing_campaign.csv")
df_konstruksi= pd.read_csv(f"{DATA_PATH}fact_konstruksi.csv")
df_sales_team= pd.read_csv(f"{DATA_PATH}dim_sales_team.csv")
df_keluhan   = pd.read_csv(f"{DATA_PATH}fact_keluhan_pelanggan.csv",
                            parse_dates=['tanggal_masuk','tanggal_selesai'])
df_cicilan   = pd.read_csv(f"{DATA_PATH}fact_cicilan_pembayaran.csv",
                            parse_dates=['tanggal_jatuh_tempo','tanggal_bayar'])

print("✅ Data loaded")


# ================================================================
# ANALISIS 1: PORTFOLIO & SALES OVERVIEW
# ================================================================

print("\n" + "=" * 60)
print("ANALISIS 1: PORTFOLIO & SALES OVERVIEW")
print("=" * 60)

# KPI Utama
total_revenue   = df_penjualan.loc[df_penjualan.status_transaksi == 'Selesai', 'harga_nett'].sum()
total_unit_sold = (df_unit.status_unit == 'Terjual').sum()
total_unit      = len(df_unit)
sold_out_rate   = total_unit_sold / total_unit * 100
avg_deal_size   = df_penjualan.loc[df_penjualan.status_transaksi=='Selesai','harga_nett'].mean()

print(f"\n{'KPI':35} {'Nilai':>20}")
print("-" * 60)
print(f"{'Total Revenue (Selesai)':35} {'Rp ' + f'{total_revenue/1e9:.1f} Miliar':>20}")
print(f"{'Unit Terjual':35} {f'{total_unit_sold:,} dari {total_unit:,}':>20}")
print(f"{'Sold-out Rate':35} {f'{sold_out_rate:.1f}%':>20}")
print(f"{'Average Deal Size':35} {'Rp ' + f'{avg_deal_size/1e6:.0f} Juta':>20}")

# Revenue per tipe proyek
rev_tipe = (
    df_penjualan.merge(df_proyek[['proyek_id','tipe_proyek']], on='proyek_id')
    .groupby('tipe_proyek')['harga_nett']
    .agg(['sum','count','mean'])
    .rename(columns={'sum':'total','count':'transaksi','mean':'avg'})
)
print("\nRevenue per Tipe Proyek:")
print(rev_tipe.assign(
    total_miliar=rev_tipe['total']/1e9,
    avg_juta=rev_tipe['avg']/1e6
)[['transaksi','total_miliar','avg_juta']].round(1).to_string())


# ================================================================
# ANALISIS 2: TREND PENJUALAN
# ================================================================

print("\n" + "=" * 60)
print("ANALISIS 2: TREND PENJUALAN TAHUNAN")
print("=" * 60)

df_penjualan['tahun']   = df_penjualan['tanggal_sp'].dt.year
df_penjualan['bulan']   = df_penjualan['tanggal_sp'].dt.month
df_penjualan['kuartal'] = df_penjualan['tanggal_sp'].dt.quarter

# YoY comparison
yoy = df_penjualan.groupby('tahun').agg(
    transaksi=('penjualan_id','count'),
    revenue=('harga_nett','sum')
).reset_index()
yoy['revenue_growth'] = yoy['revenue'].pct_change() * 100
print(yoy.assign(revenue_miliar=yoy['revenue']/1e9)[['tahun','transaksi','revenue_miliar','revenue_growth']].round(1).to_string(index=False))

# Monthly trend chart
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle('Artha Properti - Trend Penjualan', fontsize=15, fontweight='bold')

for tahun, color in [(2021,'#3498DB'),(2022,'#E74C3C'),(2023,'#27AE60'),(2024,'#F39C12')]:
    data = df_penjualan[df_penjualan['tahun'] == tahun].groupby('bulan')['harga_nett'].sum() / 1e9
    if len(data) > 0:
        axes[0].plot(data.index, data.values, marker='o', label=str(tahun), color=color)

axes[0].set_title('Revenue Bulanan per Tahun (Miliar Rp)')
axes[0].set_xlabel('Bulan'); axes[0].set_ylabel('Revenue (Miliar Rp)')
axes[0].legend(); axes[0].set_xticks(range(1, 13))
axes[0].grid(axis='y', alpha=0.3)

# Revenue per proyek bar chart
rev_proyek = df_penjualan.merge(df_proyek[['proyek_id','nama_proyek','tipe_proyek']], on='proyek_id')
rev_proyek = rev_proyek.groupby(['nama_proyek','tipe_proyek'])['harga_nett'].sum().reset_index()
rev_proyek = rev_proyek.sort_values('harga_nett', ascending=True)

colors_map = {'Apartemen': COLORS['primary'], 'Perumahan': COLORS['green'], 'Komersial': COLORS['gold']}
bar_colors = [colors_map.get(t, '#95A5A6') for t in rev_proyek['tipe_proyek']]

axes[1].barh(rev_proyek['nama_proyek'], rev_proyek['harga_nett']/1e9, color=bar_colors)
axes[1].set_title('Revenue per Proyek (Miliar Rp)')
axes[1].set_xlabel('Revenue (Miliar Rp)')

from matplotlib.patches import Patch
legend_elements = [Patch(facecolor=v, label=k) for k, v in colors_map.items()]
axes[1].legend(handles=legend_elements)
axes[1].grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('./output_trend_penjualan.png', dpi=150, bbox_inches='tight')
plt.show()
print("✅ Chart trend penjualan disimpan")


# ================================================================
# ANALISIS 3: CUSTOMER SEGMENTATION
# ================================================================

print("\n" + "=" * 60)
print("ANALISIS 3: CUSTOMER SEGMENTATION")
print("=" * 60)

# RFM Analysis
df_rfm_base = (
    df_penjualan[df_penjualan.status_transaksi == 'Selesai']
    .groupby('pelanggan_id')
    .agg(
        recency=('tanggal_sp', lambda x: (pd.Timestamp('2024-12-31') - x.max()).days),
        frequency=('penjualan_id', 'count'),
        monetary=('harga_nett', 'sum')
    )
    .reset_index()
)

# Scoring RFM (1-4, 4 is best)
df_rfm_base['R_score'] = pd.qcut(df_rfm_base['recency'],  4, labels=[4,3,2,1])
df_rfm_base['F_score'] = pd.qcut(df_rfm_base['frequency'].rank(method='first'), 4, labels=[1,2,3,4])
df_rfm_base['M_score'] = pd.qcut(df_rfm_base['monetary'], 4, labels=[1,2,3,4])

df_rfm_base['RFM_score'] = (
    df_rfm_base['R_score'].astype(int) * 100 +
    df_rfm_base['F_score'].astype(int) * 10 +
    df_rfm_base['M_score'].astype(int)
)

def rfm_segment(row):
    r, f, m = int(row['R_score']), int(row['F_score']), int(row['M_score'])
    if r >= 3 and f >= 3 and m >= 3: return 'Champions'
    elif r >= 3 and f >= 2:           return 'Loyal Customers'
    elif r >= 2 and m >= 3:           return 'Potential High Value'
    elif r == 4 and f == 1:           return 'New Customers'
    elif r <= 2 and f >= 2:           return 'At Risk'
    else:                             return 'Others'

df_rfm_base['segment'] = df_rfm_base.apply(rfm_segment, axis=1)

seg_summary = df_rfm_base.groupby('segment').agg(
    jumlah_pelanggan=('pelanggan_id','count'),
    avg_recency=('recency','mean'),
    avg_frequency=('frequency','mean'),
    avg_monetary=('monetary','mean')
).round(0)
print("\nRFM Segmentation:")
print(seg_summary.to_string())

# Visualisasi RFM
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle('Customer RFM Segmentation', fontsize=14)

seg_counts = df_rfm_base['segment'].value_counts()
axes[0].pie(seg_counts.values, labels=seg_counts.index, autopct='%1.1f%%',
            startangle=90)
axes[0].set_title('Distribusi Segmen Pelanggan')

rfm_colors = {'Champions':'#27AE60','Loyal Customers':'#2ECC71',
              'Potential High Value':'#F39C12','New Customers':'#3498DB',
              'At Risk':'#E74C3C','Others':'#BDC3C7'}
seg_monetary = df_rfm_base.groupby('segment')['monetary'].mean().sort_values(ascending=True) / 1e6
bar_colors = [rfm_colors.get(s, '#95A5A6') for s in seg_monetary.index]
axes[1].barh(seg_monetary.index, seg_monetary.values, color=bar_colors)
axes[1].set_title('Rata-rata Monetary per Segmen (Juta Rp)')
axes[1].set_xlabel('Avg Monetary (Juta Rp)')
axes[1].grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('./output_rfm_segmentation.png', dpi=150, bbox_inches='tight')
plt.show()
print("✅ RFM chart disimpan")


# ================================================================
# ANALISIS 4: MARKETING ROI
# ================================================================

print("\n" + "=" * 60)
print("ANALISIS 4: MARKETING ROI ANALYSIS")
print("=" * 60)

df_campaign['ctr']              = df_campaign['klik'] / df_campaign['impressi'] * 100
df_campaign['conversion_rate']  = df_campaign['konversi'] / df_campaign['leads'] * 100
df_campaign['cost_per_lead']    = df_campaign['pengeluaran'] / df_campaign['leads'].replace(0, np.nan)
df_campaign['cost_per_sale']    = df_campaign['pengeluaran'] / df_campaign['konversi'].replace(0, np.nan)
df_campaign['roi']              = (df_campaign['konversi'] * avg_deal_size - df_campaign['pengeluaran']) / df_campaign['pengeluaran'] * 100

channel_summary = df_campaign.groupby('channel').agg(
    total_spend=('pengeluaran','sum'),
    total_leads=('leads','sum'),
    total_konversi=('konversi','sum'),
    avg_ctr=('ctr','mean'),
    avg_conversion=('conversion_rate','mean'),
    avg_cost_per_sale=('cost_per_sale','mean'),
    avg_roi=('roi','mean')
).round(2)

print("\nChannel Performance Summary:")
print(channel_summary.to_string())

# ROI per channel visualization
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
fig.suptitle('Artha Properti - Marketing Analytics', fontsize=15, fontweight='bold')

ch = channel_summary.reset_index()

# Plot 1: Total spend
ch_sorted = ch.sort_values('total_spend', ascending=True)
axes[0,0].barh(ch_sorted['channel'], ch_sorted['total_spend']/1e6, color=COLORS['primary'])
axes[0,0].set_title('Total Marketing Spend per Channel (Juta Rp)')

# Plot 2: Conversion rate
ch_sorted2 = ch.sort_values('avg_conversion', ascending=True)
colors_bar = [COLORS['green'] if v > 5 else COLORS['red'] for v in ch_sorted2['avg_conversion']]
axes[0,1].barh(ch_sorted2['channel'], ch_sorted2['avg_conversion'], color=colors_bar)
axes[0,1].axvline(5, color='black', linestyle='--', alpha=0.5, label='Target 5%')
axes[0,1].set_title('Avg Conversion Rate per Channel (%)')
axes[0,1].legend()

# Plot 3: Cost per sale
ch_sorted3 = ch.sort_values('avg_cost_per_sale', ascending=True)
axes[1,0].barh(ch_sorted3['channel'], ch_sorted3['avg_cost_per_sale']/1e6, color=COLORS['gold'])
axes[1,0].set_title('Avg Cost per Sale per Channel (Juta Rp)')

# Plot 4: ROI
ch_sorted4 = ch.sort_values('avg_roi')
roi_colors = [COLORS['green'] if v > 0 else COLORS['red'] for v in ch_sorted4['avg_roi']]
axes[1,1].barh(ch_sorted4['channel'], ch_sorted4['avg_roi'], color=roi_colors)
axes[1,1].axvline(0, color='black', linewidth=1)
axes[1,1].set_title('Avg ROI per Channel (%)')

plt.tight_layout()
plt.savefig('./output_marketing_roi.png', dpi=150, bbox_inches='tight')
plt.show()
print("✅ Marketing ROI chart disimpan")


# ================================================================
# ANALISIS 5: SALES PERFORMANCE
# ================================================================

print("\n" + "=" * 60)
print("ANALISIS 5: SALES TEAM PERFORMANCE")
print("=" * 60)

sales_perf = (
    df_penjualan
    .merge(df_sales_team, on='sales_id', how='left')
    .groupby(['sales_id','nama_sales','jabatan','tim'])
    .agg(
        total_deal=('penjualan_id','count'),
        total_revenue=('harga_nett','sum'),
        avg_deal=('harga_nett','mean'),
        avg_diskon=('diskon_pct','mean'),
        total_batal=('status_transaksi', lambda x: (x=='Batal').sum())
    )
    .reset_index()
    .sort_values('total_revenue', ascending=False)
)

sales_perf['rank_overall']  = sales_perf['total_revenue'].rank(ascending=False).astype(int)
sales_perf['cancellation_rate'] = sales_perf['total_batal'] / sales_perf['total_deal'] * 100

print("\nTop 10 Sales Performance:")
print(sales_perf.head(10)[['nama_sales','jabatan','tim',
    'total_deal','total_revenue','avg_deal','avg_diskon','cancellation_rate']].to_string(index=False))


# ================================================================
# ANALISIS 6: KONSTRUKSI & PROGRESS
# ================================================================

print("\n" + "=" * 60)
print("ANALISIS 6: PROGRES KONSTRUKSI")
print("=" * 60)

df_konstruksi['tanggal_plan']   = pd.to_datetime(df_konstruksi['tanggal_plan'])
df_konstruksi['tanggal_aktual'] = pd.to_datetime(df_konstruksi['tanggal_aktual'])
df_konstruksi['keterlambatan_hari'] = (
    (df_konstruksi['tanggal_aktual'] - df_konstruksi['tanggal_plan'])
    .dt.days
    .fillna(0)
)
df_konstruksi['cost_overrun'] = df_konstruksi['biaya_aktual'] - df_konstruksi['biaya_plan']
df_konstruksi['cost_overrun_pct'] = df_konstruksi['cost_overrun'] / df_konstruksi['biaya_plan'] * 100

konstr_summary = (
    df_konstruksi
    .merge(df_proyek[['proyek_id','nama_proyek']], on='proyek_id')
    .groupby('nama_proyek')
    .agg(
        avg_progress=('progress_aktual_pct','mean'),
        avg_delay=('keterlambatan_hari','mean'),
        total_cost_plan=('biaya_plan','sum'),
        total_cost_actual=('biaya_aktual','sum'),
        tahapan_terlambat=('status_tahapan', lambda x: (x=='Terlambat').sum())
    )
    .round(1)
    .reset_index()
)
konstr_summary['overrun_pct'] = (
    (konstr_summary['total_cost_actual'] - konstr_summary['total_cost_plan']) 
    / konstr_summary['total_cost_plan'] * 100
).round(1)
print(konstr_summary.to_string(index=False))


# ================================================================
# ANALISIS 7: CUSTOMER SATISFACTION
# ================================================================

print("\n" + "=" * 60)
print("ANALISIS 7: CUSTOMER SATISFACTION & KELUHAN")
print("=" * 60)

df_keluhan['hari_resolusi'] = (df_keluhan['tanggal_selesai'] - df_keluhan['tanggal_masuk']).dt.days

csat = (
    df_keluhan
    .merge(df_proyek[['proyek_id','nama_proyek']], on='proyek_id')
    .groupby(['nama_proyek','kategori'])
    .agg(
        jumlah=('keluhan_id','count'),
        avg_resolusi=('hari_resolusi','mean'),
        avg_rating=('rating_kepuasan','mean'),
        kritis=('prioritas', lambda x: (x=='Kritis').sum())
    )
    .round(1)
    .reset_index()
    .sort_values('jumlah', ascending=False)
)
print(csat.head(15).to_string(index=False))

print("\n✅ Modul 3 selesai! Lanjutkan ke modul_04_visualisasi_dashboard.py")
