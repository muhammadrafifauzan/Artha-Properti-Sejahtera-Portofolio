"""
================================================================
MODUL PYTHON 4: DASHBOARD & VISUALISASI LANJUTAN
Artha Properti Sejahtera - Data Analyst Learning Path
Level: Menengah-Lanjut | Estimasi: 3 Minggu
================================================================
TOPIK: Matplotlib advanced, Seaborn, subplot complex layouts,
       storytelling with data, export-ready reports
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from matplotlib.ticker import FuncFormatter
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

DATA_PATH = "./data/"

# ─── Load & Prepare Data ────────────────────────────────────
df_proyek    = pd.read_csv(f"{DATA_PATH}dim_proyek.csv")
df_unit      = pd.read_csv(f"{DATA_PATH}dim_unit.csv")
df_pelanggan = pd.read_csv(f"{DATA_PATH}dim_pelanggan.csv")
df_penjualan = pd.read_csv(f"{DATA_PATH}fact_penjualan.csv", parse_dates=['tanggal_sp'])
df_campaign  = pd.read_csv(f"{DATA_PATH}fact_marketing_campaign.csv")
df_keluhan   = pd.read_csv(f"{DATA_PATH}fact_keluhan_pelanggan.csv", parse_dates=['tanggal_masuk','tanggal_selesai'])
df_cicilan   = pd.read_csv(f"{DATA_PATH}fact_cicilan_pembayaran.csv", parse_dates=['tanggal_jatuh_tempo','tanggal_bayar'])
df_green     = pd.read_csv(f"{DATA_PATH}dim_greenbuilding.csv")
df_sales_team= pd.read_csv(f"{DATA_PATH}dim_sales_team.csv")

df_penjualan['tahun']   = df_penjualan['tanggal_sp'].dt.year
df_penjualan['bulan']   = df_penjualan['tanggal_sp'].dt.month
df_penjualan['kuartal'] = df_penjualan['tanggal_sp'].dt.quarter

# Helper formatter
def miliar_fmt(x, pos): return f'Rp{x:.0f}M' if x < 1000 else f'Rp{x/1000:.1f}T'
def juta_fmt(x, pos): return f'{x/1e6:.0f}Jt'

print("✅ Data loaded untuk dashboard")


# ================================================================
# DASHBOARD 1: EXECUTIVE SUMMARY (Satu halaman)
# ================================================================

def create_executive_dashboard():
    fig = plt.figure(figsize=(20, 14))
    fig.patch.set_facecolor('#0D1B2A')
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.4, wspace=0.3)
    
    title_style  = dict(color='white', fontsize=13, fontweight='bold', pad=12)
    value_style  = dict(color='#F0E68C', fontsize=22, fontweight='bold', ha='center', va='center')
    label_style  = dict(color='#BDC3C7', fontsize=10, ha='center', va='center')
    
    # ── Header ──────────────────────────────────────────────────
    fig.text(0.5, 0.97, 'ARTHA PROPERTI SEJAHTERA', fontsize=22, fontweight='bold',
             ha='center', va='center', color='#F0E68C')
    fig.text(0.5, 0.945, 'Executive Dashboard — 2021-2024 Performance', fontsize=12,
             ha='center', va='center', color='#BDC3C7')
    
    # ── KPI Cards (row 0) ────────────────────────────────────────
    kpi_data = [
        ("TOTAL REVENUE", f"Rp {df_penjualan[df_penjualan.status_transaksi=='Selesai']['harga_nett'].sum()/1e9:.1f}M", "Miliar Rp"),
        ("UNIT TERJUAL",  f"{(df_unit.status_unit=='Terjual').sum():,}", f"dari {len(df_unit):,} unit"),
        ("PELANGGAN AKTIF",f"{df_penjualan['pelanggan_id'].nunique():,}", "unik"),
        ("AVG DEAL SIZE",  f"Rp {df_penjualan['harga_nett'].mean()/1e6:.0f}Jt", "Per Transaksi"),
    ]
    kpi_colors = ['#1E8449','#2874A6','#8E44AD','#D4AC0D']
    for i, (label, val, sub) in enumerate(kpi_data):
        ax = fig.add_subplot(gs[0, i])
        ax.set_facecolor(kpi_colors[i])
        ax.set_xticks([]); ax.set_yticks([])
        for spine in ax.spines.values(): spine.set_visible(False)
        ax.text(0.5, 0.65, val, **value_style, transform=ax.transAxes)
        ax.text(0.5, 0.30, label, **label_style, transform=ax.transAxes)
        ax.text(0.5, 0.12, sub, color='#ECF0F1', fontsize=9, ha='center', va='center', transform=ax.transAxes)
    
    # ── Revenue Trend (row 1, col 0-1) ──────────────────────────
    ax2 = fig.add_subplot(gs[1, 0:2])
    ax2.set_facecolor('#1C2833')
    monthly = df_penjualan.groupby(['tahun','bulan'])['harga_nett'].sum().reset_index()
    colors_line = {2021:'#3498DB',2022:'#E74C3C',2023:'#27AE60',2024:'#F39C12'}
    for yr, grp in monthly.groupby('tahun'):
        ax2.plot(grp['bulan'], grp['harga_nett']/1e9, marker='o', markersize=4,
                 label=str(yr), color=colors_line.get(yr,'white'), linewidth=2)
    ax2.set_title('Revenue Bulanan per Tahun (Miliar)', **title_style)
    ax2.set_xlabel('Bulan', color='#BDC3C7'); ax2.set_ylabel('Revenue (Miliar Rp)', color='#BDC3C7')
    ax2.tick_params(colors='#BDC3C7'); ax2.set_xticks(range(1,13))
    ax2.legend(facecolor='#1C2833', labelcolor='white', fontsize=9)
    ax2.grid(axis='y', alpha=0.2, color='white')
    for spine in ax2.spines.values(): spine.set_color('#2C3E50')
    
    # ── Sales per Proyek (row 1, col 2-3) ───────────────────────
    ax3 = fig.add_subplot(gs[1, 2:4])
    ax3.set_facecolor('#1C2833')
    rev_prj = (
        df_penjualan.merge(df_proyek[['proyek_id','nama_proyek','tipe_proyek']], on='proyek_id')
        .groupby(['nama_proyek','tipe_proyek'])['harga_nett'].sum()
        .reset_index().sort_values('harga_nett')
    )
    tp_colors = {'Apartemen':'#2E86C1','Perumahan':'#27AE60','Komersial':'#D4AC0D'}
    bar_c = [tp_colors.get(t,'#95A5A6') for t in rev_prj['tipe_proyek']]
    bars = ax3.barh(rev_prj['nama_proyek'], rev_prj['harga_nett']/1e9, color=bar_c, height=0.6)
    ax3.set_title('Revenue per Proyek (Miliar)', **title_style)
    ax3.tick_params(colors='#BDC3C7'); ax3.set_xlabel('Revenue (Miliar Rp)', color='#BDC3C7')
    ax3.grid(axis='x', alpha=0.2, color='white')
    for spine in ax3.spines.values(): spine.set_color('#2C3E50')
    patches = [mpatches.Patch(color=v, label=k) for k,v in tp_colors.items()]
    ax3.legend(handles=patches, facecolor='#1C2833', labelcolor='white', fontsize=9, loc='lower right')
    
    # ── Metode Pembayaran (row 2, col 0) ─────────────────────────
    ax4 = fig.add_subplot(gs[2, 0])
    ax4.set_facecolor('#1C2833')
    metode = df_penjualan['metode_pembayaran'].value_counts()
    palette = ['#3498DB','#E74C3C','#F39C12','#27AE60','#9B59B6']
    wedges, texts, autotexts = ax4.pie(metode.values, labels=None, autopct='%1.0f%%',
                                        colors=palette[:len(metode)], startangle=90)
    for at in autotexts: at.set_color('white'); at.set_fontsize(8)
    ax4.set_title('Metode Pembayaran', **title_style)
    ax4.legend(metode.index, facecolor='#1C2833', labelcolor='white',
               fontsize=8, loc='lower center', bbox_to_anchor=(0.5,-0.15), ncol=2)
    
    # ── Keluhan per Kategori (row 2, col 1) ───────────────────────
    ax5 = fig.add_subplot(gs[2, 1])
    ax5.set_facecolor('#1C2833')
    kat_kel = df_keluhan['kategori'].value_counts().head(5)
    ax5.barh(range(len(kat_kel)), kat_kel.values, color='#E74C3C', alpha=0.85)
    ax5.set_yticks(range(len(kat_kel)))
    ax5.set_yticklabels([k[:20] for k in kat_kel.index], color='#BDC3C7', fontsize=9)
    ax5.set_title('Top Kategori Keluhan', **title_style)
    ax5.tick_params(colors='#BDC3C7')
    ax5.grid(axis='x', alpha=0.2, color='white')
    for spine in ax5.spines.values(): spine.set_color('#2C3E50')
    
    # ── Sumber Leads (row 2, col 2) ─────────────────────────────
    ax6 = fig.add_subplot(gs[2, 2])
    ax6.set_facecolor('#1C2833')
    leads = df_pelanggan['sumber_leads'].value_counts()
    ax6.bar(leads.index, leads.values, color='#1ABC9C')
    ax6.set_title('Sumber Leads', **title_style)
    ax6.tick_params(axis='x', rotation=35, colors='#BDC3C7', labelsize=8)
    ax6.tick_params(axis='y', colors='#BDC3C7')
    ax6.grid(axis='y', alpha=0.2, color='white')
    for spine in ax6.spines.values(): spine.set_color('#2C3E50')
    
    # ── Unit Status per Proyek (row 2, col 3) ────────────────────
    ax7 = fig.add_subplot(gs[2, 3])
    ax7.set_facecolor('#1C2833')
    unit_status = (
        df_unit.merge(df_proyek[['proyek_id','nama_proyek']], on='proyek_id')
        .groupby(['nama_proyek','status_unit'])
        .size().unstack(fill_value=0)
    )
    x = np.arange(len(unit_status))
    w = 0.3
    status_colors = {'Terjual':'#27AE60','Tersedia':'#3498DB','Dipesan':'#F39C12'}
    for j, col in enumerate(unit_status.columns):
        ax7.bar(x + j*w, unit_status[col], w, label=col,
                color=status_colors.get(col,'grey'))
    ax7.set_xticks(x + w)
    prj_labels = [n.replace('Artha ','').replace(' ','\n') for n in unit_status.index]
    ax7.set_xticklabels(prj_labels, fontsize=7, color='#BDC3C7')
    ax7.set_title('Status Unit per Proyek', **title_style)
    ax7.tick_params(axis='y', colors='#BDC3C7')
    ax7.legend(facecolor='#1C2833', labelcolor='white', fontsize=8)
    ax7.grid(axis='y', alpha=0.2, color='white')
    for spine in ax7.spines.values(): spine.set_color('#2C3E50')
    
    plt.savefig('./output_executive_dashboard.png', dpi=150, bbox_inches='tight',
                facecolor=fig.get_facecolor())
    plt.show()
    print("✅ Executive Dashboard disimpan: output_executive_dashboard.png")

create_executive_dashboard()


# ================================================================
# DASHBOARD 2: GREEN BUILDING REPORT
# ================================================================

def create_green_report():
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('Artha Properti Sejahtera\nGreen Building & Sustainability Report',
                 fontsize=16, fontweight='bold', color='#1E8449')
    
    df_gb_full = df_green.merge(df_proyek[['proyek_id','nama_proyek','tipe_proyek']], on='proyek_id')
    
    # Plot 1: Sertifikasi level
    level_order = ['Bronze','Silver','Gold','Platinum']
    level_count = df_gb_full['level_sertifikasi'].value_counts().reindex(level_order).fillna(0)
    level_colors = {'Bronze':'#CD7F32','Silver':'#C0C0C0','Gold':'#FFD700','Platinum':'#E5E4E2'}
    axes[0,0].bar(level_count.index, level_count.values,
                  color=[level_colors[l] for l in level_count.index], edgecolor='grey')
    axes[0,0].set_title('Distribusi Level Sertifikasi Green Building')
    axes[0,0].set_ylabel('Jumlah Proyek')
    
    # Plot 2: Penghematan energi & air
    x = np.arange(len(df_gb_full))
    w = 0.35
    axes[0,1].bar(x - w/2, df_gb_full['penghematan_energi_pct'], w,
                  label='Penghematan Energi', color='#F39C12', alpha=0.8)
    axes[0,1].bar(x + w/2, df_gb_full['penghematan_air_pct'], w,
                  label='Penghematan Air', color='#3498DB', alpha=0.8)
    axes[0,1].set_xticks(x)
    axes[0,1].set_xticklabels(
        [n.replace('Artha ','') for n in df_gb_full['nama_proyek']],
        rotation=30, ha='right', fontsize=9)
    axes[0,1].set_title('Penghematan Energi & Air per Proyek (%)')
    axes[0,1].set_ylabel('Persentase Penghematan')
    axes[0,1].legend()
    axes[0,1].axhline(25, color='red', linestyle='--', alpha=0.5, label='Target 25%')
    
    # Plot 3: Pengurangan karbon
    axes[1,0].barh(df_gb_full['nama_proyek'], df_gb_full['pengurangan_karbon_pct'],
                   color='#27AE60', alpha=0.8)
    axes[1,0].set_title('Pengurangan Emisi Karbon per Proyek (%)')
    axes[1,0].set_xlabel('Pengurangan (%)')
    axes[1,0].axvline(20, color='red', linestyle='--', alpha=0.5, label='Target 20%')
    axes[1,0].legend()
    
    # Plot 4: Scatter - Sertifikasi vs Keluhan
    kel_proyek = df_keluhan.groupby('proyek_id').agg(
        total_keluhan=('keluhan_id','count'),
        avg_rating=('rating_kepuasan','mean')
    ).reset_index()
    scatter_data = df_gb_full.merge(kel_proyek, on='proyek_id', how='left').fillna(0)
    level_num = {'Bronze':1,'Silver':2,'Gold':3,'Platinum':4}
    scatter_data['level_num'] = scatter_data['level_sertifikasi'].map(level_num)
    
    sc = axes[1,1].scatter(scatter_data['level_num'], scatter_data['avg_rating'],
                           s=scatter_data['total_keluhan']*10+100,
                           c=scatter_data['penghematan_energi_pct'], cmap='Greens',
                           alpha=0.8, edgecolors='black')
    axes[1,1].set_xticks([1,2,3,4])
    axes[1,1].set_xticklabels(['Bronze','Silver','Gold','Platinum'])
    for _, row in scatter_data.iterrows():
        axes[1,1].annotate(row['nama_proyek'].replace('Artha ',''),
                           (row['level_num'], row['avg_rating']),
                           fontsize=8, ha='center', va='bottom')
    plt.colorbar(sc, ax=axes[1,1], label='Penghematan Energi (%)')
    axes[1,1].set_title('Level Sertifikasi vs Rating Kepuasan\n(ukuran = jumlah keluhan)')
    axes[1,1].set_xlabel('Level Sertifikasi')
    axes[1,1].set_ylabel('Avg Rating Kepuasan')
    
    plt.tight_layout()
    plt.savefig('./output_green_building_report.png', dpi=150, bbox_inches='tight')
    plt.show()
    print("✅ Green Building Report disimpan")

create_green_report()


# ================================================================
# LATIHAN MANDIRI MODUL 4
# ================================================================
"""
TANTANGAN PROYEK AKHIR:
Buat satu dashboard komprehensif "Artha Properti Monthly Report"
untuk bulan Desember 2023, berisi:

1. KPI utama (revenue, unit terjual, avg deal size) vs bulan lalu
2. Breakdown penjualan per proyek (bar chart)
3. Top 5 sales eksekutif bulan tersebut
4. Status cicilan (% tepat waktu vs terlambat)
5. Keluhan masuk vs selesai
6. Rekomendasi 3 action item berdasarkan data

Format: Satu figure, 2x3 grid, tema profesional
Simpan: output_monthly_report_dec2023.png
"""

print("\n🎓 Modul 4 selesai! Lanjut ke modul_05_sql_python_integration.py")
print("   Selamat! Anda telah menyelesaikan core curriculum.")
