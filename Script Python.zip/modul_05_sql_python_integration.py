"""
================================================================
MODUL PYTHON 5: SQL + PYTHON INTEGRATION
Artha Properti Sejahtera - Data Analyst Learning Path
Level: Lanjut | Estimasi: 2 Minggu
================================================================
TOPIK: SQLite integration, SQLAlchemy, pandas + SQL workflow,
       automated reporting, export to Excel
"""

import pandas as pd
import numpy as np
import sqlite3
import os
import warnings
warnings.filterwarnings('ignore')

DATA_PATH = "./data/"
DB_PATH   = "./data/artha_properti.db"


# ================================================================
# BAGIAN 1: BUAT DATABASE SQLITE & IMPORT DATA
# ================================================================

print("=" * 60)
print("BAGIAN 1: SETUP SQLITE DATABASE")
print("=" * 60)

def buat_database():
    """Load semua CSV ke SQLite"""
    conn = sqlite3.connect(DB_PATH)
    
    tables = {
        'dim_proyek':                'dim_proyek.csv',
        'dim_unit':                  'dim_unit.csv',
        'dim_pelanggan':             'dim_pelanggan.csv',
        'dim_sales_team':            'dim_sales_team.csv',
        'dim_greenbuilding':         'dim_greenbuilding.csv',
        'fact_penjualan':            'fact_penjualan.csv',
        'fact_marketing_campaign':   'fact_marketing_campaign.csv',
        'fact_konstruksi':           'fact_konstruksi.csv',
        'fact_keluhan_pelanggan':    'fact_keluhan_pelanggan.csv',
        'fact_cicilan_pembayaran':   'fact_cicilan_pembayaran.csv',
    }
    
    for tabel, file in tables.items():
        df = pd.read_csv(f"{DATA_PATH}{file}")
        df.to_sql(tabel, conn, if_exists='replace', index=False)
        print(f"  ✅ {tabel}: {len(df):,} rows")
    
    conn.close()
    print(f"\nDatabase disimpan: {DB_PATH}")
    return DB_PATH

buat_database()


# ================================================================
# BAGIAN 2: QUERY SQL DARI PYTHON
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 2: QUERY SQL DARI PYTHON")
print("=" * 60)

def run_query(sql, db_path=DB_PATH):
    """Helper: jalankan SQL dan return DataFrame"""
    with sqlite3.connect(db_path) as conn:
        return pd.read_sql(sql, conn)

# Query 1: Revenue per proyek
q1 = run_query("""
    SELECT 
        p.nama_proyek,
        p.tipe_proyek,
        COUNT(f.penjualan_id)   AS total_transaksi,
        SUM(f.harga_nett)       AS total_revenue,
        AVG(f.harga_nett)       AS avg_deal
    FROM fact_penjualan f
    INNER JOIN dim_proyek p ON f.proyek_id = p.proyek_id
    WHERE f.status_transaksi = 'Selesai'
    GROUP BY p.nama_proyek, p.tipe_proyek
    ORDER BY total_revenue DESC
""")
print("\nRevenue per Proyek:")
print(q1.to_string(index=False))

# Query 2: Monthly sales 2023
q2 = run_query("""
    SELECT 
        strftime('%Y-%m', tanggal_sp) AS periode,
        COUNT(*) AS unit_terjual,
        SUM(harga_nett) AS revenue
    FROM fact_penjualan
    WHERE strftime('%Y', tanggal_sp) = '2023'
      AND status_transaksi != 'Batal'
    GROUP BY strftime('%Y-%m', tanggal_sp)
    ORDER BY periode
""")
print("\nMonthly Sales 2023:")
print(q2.to_string(index=False))

# Query 3: Sales Performance (JOIN kompleks)
q3 = run_query("""
    SELECT 
        st.nama_sales,
        st.jabatan,
        st.tim,
        COUNT(f.penjualan_id)   AS total_deal,
        SUM(f.harga_nett)       AS total_revenue,
        ROUND(AVG(f.diskon_pct), 2) AS avg_diskon,
        RANK() OVER (ORDER BY SUM(f.harga_nett) DESC) AS rank_overall
    FROM dim_sales_team st
    LEFT JOIN fact_penjualan f ON st.sales_id = f.sales_id
    GROUP BY st.sales_id, st.nama_sales, st.jabatan, st.tim
    ORDER BY total_revenue DESC
    LIMIT 10
""")
print("\nTop 10 Sales:")
print(q3.to_string(index=False))


# ================================================================
# BAGIAN 3: AUTOMATED REPORT KE EXCEL
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 3: EXPORT LAPORAN KE EXCEL")
print("=" * 60)

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

def style_header(cell, color='1B4F72'):
    cell.font = Font(bold=True, color='FFFFFF', size=11)
    cell.fill = PatternFill('solid', start_color=color)
    cell.alignment = Alignment(horizontal='center', vertical='center')
    thin = Side(style='thin', color='FFFFFF')
    cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)

def style_row(cell, even=True):
    bg = 'EAF2F8' if even else 'FFFFFF'
    cell.fill = PatternFill('solid', start_color=bg)
    cell.alignment = Alignment(horizontal='left', vertical='center')

def create_excel_report(output_path='./output_monthly_report.xlsx'):
    wb = Workbook()
    
    # ── Sheet 1: Revenue Summary ──────────────────────────────
    ws1 = wb.active
    ws1.title = 'Revenue Summary'
    
    data_rev = run_query("""
        SELECT p.nama_proyek, p.tipe_proyek, p.kota,
               COUNT(f.penjualan_id) AS transaksi,
               SUM(f.harga_nett) AS revenue,
               AVG(f.harga_nett) AS avg_deal,
               MIN(f.tanggal_sp) AS first_sale,
               MAX(f.tanggal_sp) AS last_sale
        FROM fact_penjualan f
        JOIN dim_proyek p ON f.proyek_id = p.proyek_id
        GROUP BY p.nama_proyek, p.tipe_proyek, p.kota
        ORDER BY revenue DESC
    """)
    
    ws1['A1'] = 'LAPORAN REVENUE ARTHA PROPERTI SEJAHTERA'
    ws1['A1'].font = Font(bold=True, size=14, color='1B4F72')
    ws1.merge_cells('A1:H1')
    ws1['A1'].alignment = Alignment(horizontal='center')
    ws1.row_dimensions[1].height = 30
    
    ws1['A2'] = 'Periode: 2021-2024'
    ws1['A2'].font = Font(italic=True, color='7F8C8D')
    ws1.row_dimensions[3].height = 22
    
    headers = ['Nama Proyek','Tipe','Kota','Transaksi','Revenue (Rp)','Avg Deal (Rp)','Pertama','Terakhir']
    for col, h in enumerate(headers, 1):
        cell = ws1.cell(row=3, column=col, value=h)
        style_header(cell)
    
    for r, row in data_rev.iterrows():
        ws_row = r + 4
        values = list(row)
        for c, val in enumerate(values, 1):
            cell = ws1.cell(row=ws_row, column=c, value=val)
            style_row(cell, even=(r % 2 == 0))
            if c in [5, 6]:
                cell.number_format = '#,##0'
    
    col_widths = [28, 14, 18, 12, 20, 20, 14, 14]
    for i, w in enumerate(col_widths, 1):
        ws1.column_dimensions[ws1.cell(1, i).column_letter].width = w
    
    # ── Sheet 2: Monthly Trend ──────────────────────────────
    ws2 = wb.create_sheet('Trend Bulanan')
    data_monthly = run_query("""
        SELECT 
            strftime('%Y', tanggal_sp) AS tahun,
            strftime('%m', tanggal_sp) AS bulan,
            COUNT(*) AS unit_terjual,
            SUM(harga_nett) AS revenue
        FROM fact_penjualan
        WHERE status_transaksi != 'Batal'
        GROUP BY 1, 2 ORDER BY 1, 2
    """)
    
    ws2['A1'] = 'TREND PENJUALAN BULANAN'
    ws2['A1'].font = Font(bold=True, size=14, color='1B4F72')
    ws2.merge_cells('A1:D1')
    ws2['A1'].alignment = Alignment(horizontal='center')
    
    headers2 = ['Tahun','Bulan','Unit Terjual','Revenue (Rp)']
    for col, h in enumerate(headers2, 1):
        cell = ws2.cell(row=3, column=col, value=h)
        style_header(cell)
    
    for r, row in data_monthly.iterrows():
        ws_row = r + 4
        for c, val in enumerate(list(row), 1):
            cell = ws2.cell(row=ws_row, column=c, value=val)
            style_row(cell, even=(r % 2 == 0))
            if c == 4:
                cell.number_format = '#,##0'
    
    for i in range(1, 5):
        ws2.column_dimensions[ws2.cell(1, i).column_letter].width = 15
    
    # ── Sheet 3: Sales Performance ─────────────────────────────
    ws3 = wb.create_sheet('Sales Performance')
    data_sales = run_query("""
        SELECT st.nama_sales, st.jabatan, st.tim,
               COUNT(f.penjualan_id) AS total_deal,
               COALESCE(SUM(f.harga_nett), 0) AS revenue,
               ROUND(COALESCE(AVG(f.diskon_pct),0), 2) AS avg_diskon
        FROM dim_sales_team st
        LEFT JOIN fact_penjualan f ON st.sales_id = f.sales_id
        GROUP BY st.sales_id ORDER BY revenue DESC
    """)
    
    ws3['A1'] = 'PERFORMA TIM SALES'
    ws3['A1'].font = Font(bold=True, size=14, color='1B4F72')
    ws3.merge_cells('A1:F1')
    ws3['A1'].alignment = Alignment(horizontal='center')
    
    headers3 = ['Nama Sales','Jabatan','Tim','Total Deal','Revenue (Rp)','Avg Diskon (%)']
    for col, h in enumerate(headers3, 1):
        cell = ws3.cell(row=3, column=col, value=h)
        style_header(cell, color='145A32')
    
    for r, row in data_sales.iterrows():
        ws_row = r + 4
        for c, val in enumerate(list(row), 1):
            cell = ws3.cell(row=ws_row, column=c, value=val)
            style_row(cell, even=(r % 2 == 0))
            if c == 5:
                cell.number_format = '#,##0'
    
    col_widths3 = [25, 20, 10, 12, 20, 16]
    for i, w in enumerate(col_widths3, 1):
        ws3.column_dimensions[ws3.cell(1, i).column_letter].width = w
    
    wb.save(output_path)
    print(f"✅ Laporan Excel disimpan: {output_path}")
    return output_path

create_excel_report()


# ================================================================
# BAGIAN 4: AUTOMATED KPI ALERTS
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 4: KPI MONITORING & ALERTS")
print("=" * 60)

def check_kpi_alerts():
    alerts = []
    
    # Alert 1: Unit tersedia < 10%
    unit_status = run_query("""
        SELECT proyek_id,
               SUM(CASE WHEN status_unit='Tersedia' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS pct_tersedia
        FROM dim_unit GROUP BY proyek_id
    """).merge(run_query("SELECT proyek_id, nama_proyek FROM dim_proyek"), on='proyek_id')
    
    for _, row in unit_status[unit_status['pct_tersedia'] < 10].iterrows():
        alerts.append({
            'tipe': '🔴 CRITICAL',
            'pesan': f"{row['nama_proyek']}: Hanya {row['pct_tersedia']:.1f}% unit tersisa!"
        })
    
    # Alert 2: Keluhan eskalasi tidak selesai
    eskalasi = run_query("""
        SELECT COUNT(*) AS jumlah FROM fact_keluhan_pelanggan 
        WHERE status = 'Eskalasi' AND tanggal_selesai IS NULL
    """)
    if eskalasi['jumlah'].iloc[0] > 5:
        alerts.append({
            'tipe': '🟡 WARNING',
            'pesan': f"{eskalasi['jumlah'].iloc[0]} keluhan eskalasi belum diselesaikan"
        })
    
    # Alert 3: Tingkat keterlambatan cicilan > 15%
    cicilan_rate = run_query("""
        SELECT 
            SUM(CASE WHEN ketepatan_bayar='Terlambat' THEN 1.0 ELSE 0 END) * 100 / COUNT(*) AS pct_terlambat
        FROM fact_cicilan_pembayaran
    """)
    rate = cicilan_rate['pct_terlambat'].iloc[0]
    if rate > 15:
        alerts.append({
            'tipe': '🟡 WARNING',
            'pesan': f"Tingkat keterlambatan cicilan: {rate:.1f}% (threshold: 15%)"
        })
    
    print("\n=== KPI ALERTS ===")
    if alerts:
        for a in alerts:
            print(f"  {a['tipe']}: {a['pesan']}")
    else:
        print("  ✅ Semua KPI dalam kondisi normal")
    
    return alerts

check_kpi_alerts()

print("\n🏆 Modul 5 selesai! Anda telah menguasai integrasi SQL + Python.")
print("   Silakan lanjutkan ke proyek_akhir/ untuk capstone project.")
