# ============================================================
# ARTHA PROPERTI SEJAHTERA - ANALISIS DATA DENGAN PYTHON
# ============================================================
# Kurikulum Data Analyst Property Developer
# Tools: Python, Pandas, Matplotlib, Seaborn, SQLite
# ============================================================

# CARA MENJALANKAN:
# pip install pandas matplotlib seaborn sqlite3 openpyxl
# python analysis.py
# Atau buka di Jupyter: jupyter notebook

# ============================================================
# SETUP - Import Library & Load Data
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import sqlite3
import warnings
from datetime import datetime, timedelta

warnings.filterwarnings('ignore')
pd.set_option('display.float_format', lambda x: f'{x:,.0f}')
pd.set_option('display.max_columns', None)
plt.rcParams['figure.figsize'] = (12, 6)
plt.rcParams['font.size'] = 11
sns.set_theme(style='whitegrid', palette='muted')

# ============================================================
# INISIALISASI DATABASE SQLITE
# ============================================================

def init_database():
    """
    Membuat database SQLite dari file CSV.
    Ini adalah cara paling mudah belajar SQL + Python sekaligus.
    """
    conn = sqlite3.connect('artha_properti.db')
    tables = {
        'employees':         'data/employees.csv',
        'projects':          'data/projects.csv',
        'units':             'data/units.csv',
        'customers':         'data/customers.csv',
        'unit_sales':        'data/unit_sales.csv',
        'payment_transactions': 'data/payment_transactions.csv',
        'marketing_campaigns':  'data/marketing_campaigns.csv',
        'marketing_leads':   'data/marketing_leads.csv',
        'green_certifications': 'data/green_certifications.csv',
        'sustainability_metrics': 'data/sustainability_metrics.csv',
    }
    for table, filepath in tables.items():
        try:
            df = pd.read_csv(filepath)
            df.to_sql(table, conn, if_exists='replace', index=False)
            print(f"  ✅ {table}: {len(df):,} rows")
        except Exception as e:
            print(f"  ❌ {table}: {e}")
    conn.commit()
    return conn

print("=" * 60)
print("  ARTHA PROPERTI SEJAHTERA - DATA ANALYSIS TOOLKIT")
print("=" * 60)
print("\nMemuat database...")
conn = init_database()

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def query(sql, params=None):
    """Wrapper mudah untuk query SQL"""
    return pd.read_sql_query(sql, conn, params=params)

def format_rp(angka):
    """Format angka menjadi Rupiah"""
    if angka >= 1_000_000_000_000:
        return f"Rp {angka/1_000_000_000_000:.1f}T"
    elif angka >= 1_000_000_000:
        return f"Rp {angka/1_000_000_000:.1f}M"
    elif angka >= 1_000_000:
        return f"Rp {angka/1_000_000:.0f}jt"
    return f"Rp {angka:,.0f}"

# ============================================================
# MODUL 1: EKSPLORASI DATA (EDA)
# ============================================================

print("\n" + "="*60)
print("MODUL 1: EKSPLORASI DATA DASAR")
print("="*60)

# 1.1 Overview semua tabel
print("\n📊 Ringkasan Dataset:")
tables_info = query("""
    SELECT 'employees' as tabel, COUNT(*) as rows FROM employees
    UNION ALL SELECT 'projects', COUNT(*) FROM projects
    UNION ALL SELECT 'units', COUNT(*) FROM units
    UNION ALL SELECT 'customers', COUNT(*) FROM customers
    UNION ALL SELECT 'unit_sales', COUNT(*) FROM unit_sales
    UNION ALL SELECT 'payment_transactions', COUNT(*) FROM payment_transactions
    UNION ALL SELECT 'marketing_leads', COUNT(*) FROM marketing_leads
""")
print(tables_info.to_string(index=False))

# 1.2 Load dataframes utama
df_sales   = pd.read_csv('data/unit_sales.csv', parse_dates=['sale_date','contract_date'])
df_units   = pd.read_csv('data/units.csv')
df_proj    = pd.read_csv('data/projects.csv')
df_cust    = pd.read_csv('data/customers.csv', parse_dates=['registration_date'])
df_leads   = pd.read_csv('data/marketing_leads.csv', parse_dates=['lead_date'])
df_camp    = pd.read_csv('data/marketing_campaigns.csv', parse_dates=['start_date'])
df_sustain = pd.read_csv('data/sustainability_metrics.csv', parse_dates=['metric_date'])
df_emp     = pd.read_csv('data/employees.csv', parse_dates=['hire_date'])

# 1.3 Cek missing values
print("\n🔍 Missing Values per Tabel (Unit Sales):")
missing = df_sales.isnull().sum()
missing = missing[missing > 0]
if len(missing) > 0:
    print(missing)
else:
    print("  Tidak ada missing values kritis")

# 1.4 Statistik dasar penjualan
print("\n📈 Statistik Harga Jual:")
print(df_sales['net_price'].describe().apply(format_rp))

# ============================================================
# MODUL 2: ANALISIS PENJUALAN (Revenue Analysis)
# ============================================================

print("\n" + "="*60)
print("MODUL 2: REVENUE & PENJUALAN ANALYSIS")
print("="*60)

# 2.1 Revenue per Proyek
revenue_proj = query("""
    SELECT 
        p.project_name,
        p.project_type,
        COUNT(s.sale_id) AS unit_terjual,
        SUM(s.net_price) AS total_revenue,
        AVG(s.net_price) AS avg_harga
    FROM unit_sales s
    JOIN units u ON s.unit_id = u.unit_id
    JOIN projects p ON u.project_id = p.project_id
    WHERE s.sale_status IN ('signed', 'paid')
    GROUP BY p.project_name, p.project_type
    ORDER BY total_revenue DESC
""")

print("\n🏢 Revenue per Proyek:")
for _, row in revenue_proj.iterrows():
    bar = "█" * int(row['total_revenue'] / 50_000_000_000)
    print(f"  {row['project_name'][:30]:<30} {format_rp(row['total_revenue']):>12}  {bar}")

# 2.2 Visualisasi Revenue per Proyek
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Bar chart revenue
colors = {'perumahan': '#2196F3', 'apartemen': '#4CAF50', 'komersial': '#FF9800'}
bar_colors = [colors.get(t, '#9E9E9E') for t in revenue_proj['project_type']]
axes[0].barh(
    [n[:25] for n in revenue_proj['project_name']], 
    revenue_proj['total_revenue'] / 1e9,
    color=bar_colors
)
axes[0].set_xlabel('Revenue (Miliar Rp)')
axes[0].set_title('Total Revenue per Proyek', fontweight='bold')
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor=v, label=k) for k,v in colors.items()]
axes[0].legend(handles=legend_elements)

# Pie chart by type
type_revenue = revenue_proj.groupby('project_type')['total_revenue'].sum()
axes[1].pie(type_revenue.values, labels=type_revenue.index, autopct='%1.1f%%',
            colors=['#2196F3','#4CAF50','#FF9800'], startangle=90)
axes[1].set_title('Kontribusi Revenue per Tipe Properti', fontweight='bold')

plt.tight_layout()
plt.savefig('output/01_revenue_per_proyek.png', dpi=150, bbox_inches='tight')
plt.close()
print("  → Grafik disimpan: output/01_revenue_per_proyek.png")

# 2.3 Tren Penjualan Bulanan
df_sales_valid = df_sales[df_sales['sale_status'].isin(['signed','paid'])].copy()
df_sales_valid['tahun_bulan'] = df_sales_valid['sale_date'].dt.to_period('M')

monthly_revenue = df_sales_valid.groupby('tahun_bulan').agg(
    unit_terjual=('sale_id', 'count'),
    total_revenue=('net_price', 'sum')
).reset_index()
monthly_revenue['tahun_bulan'] = monthly_revenue['tahun_bulan'].astype(str)
monthly_revenue['MA3'] = monthly_revenue['total_revenue'].rolling(3).mean()

fig, ax1 = plt.subplots(figsize=(16, 6))
ax2 = ax1.twinx()

ax1.bar(range(len(monthly_revenue)), monthly_revenue['total_revenue']/1e9,
        color='#42A5F5', alpha=0.7, label='Revenue Bulanan')
ax2.plot(range(len(monthly_revenue)), monthly_revenue['unit_terjual'],
         'o-', color='#FF7043', linewidth=2, label='Unit Terjual')
ax1.plot(range(len(monthly_revenue)), monthly_revenue['MA3']/1e9,
         '--', color='#1A237E', linewidth=2, label='MA-3 Bulan')

ax1.set_xlabel('Periode')
ax1.set_ylabel('Revenue (Miliar Rp)', color='#42A5F5')
ax2.set_ylabel('Unit Terjual', color='#FF7043')
ax1.set_title('Tren Penjualan Bulanan Artha Properti Sejahtera', fontweight='bold', fontsize=14)
xticks = range(0, len(monthly_revenue), 2)
ax1.set_xticks(xticks)
ax1.set_xticklabels([monthly_revenue['tahun_bulan'].iloc[i] for i in xticks], rotation=45, ha='right')

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left')

plt.tight_layout()
plt.savefig('output/02_tren_penjualan_bulanan.png', dpi=150, bbox_inches='tight')
plt.close()
print("  → Grafik disimpan: output/02_tren_penjualan_bulanan.png")

# ============================================================
# MODUL 3: INVENTORY ANALYSIS
# ============================================================

print("\n" + "="*60)
print("MODUL 3: ANALISIS INVENTORI UNIT")
print("="*60)

# 3.1 Status unit per proyek
inventory = query("""
    SELECT 
        p.project_name,
        p.project_type,
        SUM(CASE WHEN u.status='available' THEN 1 ELSE 0 END) AS available,
        SUM(CASE WHEN u.status='booked' THEN 1 ELSE 0 END) AS booked,
        SUM(CASE WHEN u.status='sold' THEN 1 ELSE 0 END) AS sold,
        COUNT(*) AS total,
        ROUND(SUM(CASE WHEN u.status='sold' THEN 1 ELSE 0 END)*100.0/COUNT(*),1) AS sold_pct
    FROM units u JOIN projects p ON u.project_id=p.project_id
    GROUP BY p.project_name, p.project_type
    ORDER BY sold_pct DESC
""")

print("\n📦 Status Inventori per Proyek:")
print(inventory[['project_name','available','booked','sold','total','sold_pct']].to_string(index=False))

# Stacked bar chart
fig, ax = plt.subplots(figsize=(14, 7))
names = [n[:20] for n in inventory['project_name']]
x = range(len(names))
ax.bar(x, inventory['available'], label='Available', color='#66BB6A')
ax.bar(x, inventory['booked'], bottom=inventory['available'], label='Booked', color='#FFA726')
ax.bar(x, inventory['sold'], bottom=inventory['available']+inventory['booked'], label='Sold', color='#EF5350')
ax.set_xticks(x)
ax.set_xticklabels(names, rotation=30, ha='right')
ax.set_ylabel('Jumlah Unit')
ax.set_title('Status Inventori Unit per Proyek', fontweight='bold', fontsize=13)
ax.legend()
for i, (_, row) in enumerate(inventory.iterrows()):
    ax.text(i, row['total']+5, f"{row['sold_pct']:.0f}%", ha='center', fontsize=9, color='#D32F2F', fontweight='bold')
plt.tight_layout()
plt.savefig('output/03_inventory_status.png', dpi=150, bbox_inches='tight')
plt.close()
print("  → Grafik disimpan: output/03_inventory_status.png")

# ============================================================
# MODUL 4: CUSTOMER ANALYSIS (Segmentasi & Profiling)
# ============================================================

print("\n" + "="*60)
print("MODUL 4: ANALISIS CUSTOMER")
print("="*60)

# 4.1 Customer acquisition source
src_analysis = query("""
    SELECT 
        acquisition_source,
        COUNT(*) AS total_customer,
        ROUND(COUNT(*)*100.0/(SELECT COUNT(*) FROM customers),1) AS pct
    FROM customers
    GROUP BY acquisition_source
    ORDER BY total_customer DESC
""")

# 4.2 Customer Segmentasi berdasarkan nilai pembelian (RFM-lite)
customer_value = query("""
    SELECT 
        c.customer_id,
        c.full_name,
        c.customer_type,
        c.occupation,
        c.monthly_income,
        COUNT(s.sale_id) AS frequency,
        COALESCE(SUM(s.net_price), 0) AS monetary,
        MAX(s.sale_date) AS last_purchase
    FROM customers c
    LEFT JOIN unit_sales s ON c.customer_id = s.customer_id 
        AND s.sale_status IN ('signed','paid')
    GROUP BY c.customer_id, c.full_name, c.customer_type, c.occupation, c.monthly_income
""")

# Segmentasi sederhana
def segment_customer(row):
    if row['monetary'] >= 5_000_000_000:
        return 'Champion'
    elif row['monetary'] >= 2_000_000_000:
        return 'Loyal'
    elif row['monetary'] >= 500_000_000:
        return 'Promising'
    elif row['monetary'] > 0:
        return 'New Buyer'
    else:
        return 'Prospect'

customer_value['segment'] = customer_value.apply(segment_customer, axis=1)

seg_summary = customer_value.groupby('segment').agg(
    jumlah=('customer_id','count'),
    total_revenue=('monetary','sum'),
    avg_revenue=('monetary','mean')
).reset_index()

print("\n👥 Customer Segmentasi:")
for _, row in seg_summary.sort_values('total_revenue',ascending=False).iterrows():
    print(f"  {row['segment']:<12} | {row['jumlah']:>4} customer | {format_rp(row['total_revenue']):>12}")

# Visualisasi customer
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

# Acquisition source
axes[0].pie(src_analysis['total_customer'], labels=src_analysis['acquisition_source'],
            autopct='%1.1f%%', startangle=90)
axes[0].set_title('Sumber Akuisisi Customer', fontweight='bold')

# Customer segment
seg_plot = seg_summary.sort_values('total_revenue', ascending=False)
axes[1].bar(seg_plot['segment'], seg_plot['jumlah'], color=['#B71C1C','#E53935','#FB8C00','#43A047','#1E88E5'])
axes[1].set_title('Distribusi Segmen Customer', fontweight='bold')
axes[1].set_ylabel('Jumlah Customer')
axes[1].tick_params(axis='x', rotation=15)

# Customer type distribution
type_count = customer_value['customer_type'].value_counts()
axes[2].pie(type_count.values, labels=type_count.index, autopct='%1.1f%%', startangle=90,
            colors=['#1565C0','#2E7D32','#E65100'])
axes[2].set_title('Tipe Customer', fontweight='bold')

plt.tight_layout()
plt.savefig('output/04_customer_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print("  → Grafik disimpan: output/04_customer_analysis.png")

# ============================================================
# MODUL 5: MARKETING ANALYTICS
# ============================================================

print("\n" + "="*60)
print("MODUL 5: MARKETING PERFORMANCE")
print("="*60)

# 5.1 ROI per Channel
channel_perf = query("""
    SELECT 
        channel,
        COUNT(*) AS jumlah_campaign,
        SUM(actual_spend) AS total_spend,
        SUM(actual_leads) AS total_leads,
        SUM(conversions) AS total_conversions,
        ROUND(SUM(actual_spend)*1.0/NULLIF(SUM(actual_leads),0),0) AS cost_per_lead,
        ROUND(SUM(conversions)*100.0/NULLIF(SUM(actual_leads),0),1) AS avg_conversion_rate
    FROM marketing_campaigns
    GROUP BY channel
    ORDER BY avg_conversion_rate DESC
""")

print("\n📣 Performa Marketing per Channel:")
print(channel_perf[['channel','jumlah_campaign','total_leads','total_conversions','avg_conversion_rate']].to_string(index=False))

# 5.2 Lead Funnel
lead_funnel = query("""
    SELECT lead_status, COUNT(*) AS jumlah
    FROM marketing_leads
    GROUP BY lead_status
    ORDER BY jumlah DESC
""")

# Visualisasi Marketing
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Channel performance
channel_sorted = channel_perf.sort_values('avg_conversion_rate', ascending=True)
colors_ch = plt.cm.RdYlGn(np.linspace(0.2, 0.9, len(channel_sorted)))
axes[0].barh(channel_sorted['channel'], channel_sorted['avg_conversion_rate'], color=colors_ch)
axes[0].set_xlabel('Conversion Rate (%)')
axes[0].set_title('Conversion Rate per Channel Marketing', fontweight='bold')
for i, v in enumerate(channel_sorted['avg_conversion_rate']):
    axes[0].text(v + 0.1, i, f'{v:.1f}%', va='center')

# Funnel
funnel_order = ['new','contacted','interested','hot','converted','dead']
funnel_data = lead_funnel.set_index('lead_status').reindex(funnel_order).reset_index()
funnel_colors = ['#1976D2','#388E3C','#F57C00','#D32F2F','#7B1FA2','#616161']
axes[1].bar(funnel_data['lead_status'], funnel_data['jumlah'], color=funnel_colors)
axes[1].set_title('Lead Funnel Distribution', fontweight='bold')
axes[1].set_ylabel('Jumlah Lead')
for i, v in enumerate(funnel_data['jumlah']):
    axes[1].text(i, v + 5, str(int(v)), ha='center', fontweight='bold')

plt.tight_layout()
plt.savefig('output/05_marketing_performance.png', dpi=150, bbox_inches='tight')
plt.close()
print("  → Grafik disimpan: output/05_marketing_performance.png")

# ============================================================
# MODUL 6: SUSTAINABILITY ANALYSIS (USP Artha Properti)
# ============================================================

print("\n" + "="*60)
print("MODUL 6: SUSTAINABILITY METRICS (GREEN ANALYTICS)")
print("="*60)

# 6.1 Sustainability per proyek
sustain_proj = query("""
    SELECT 
        p.project_name,
        ROUND(AVG(sm.solar_kwh / NULLIF(sm.energy_kwh,0)) * 100, 1) AS pct_renewable_energy,
        ROUND(SUM(sm.co2_saved_kg)/1000, 1) AS co2_saved_ton,
        ROUND(AVG(sm.recycled_waste_pct), 1) AS avg_recycle_pct,
        ROUND(AVG(sm.green_area_m2), 0) AS avg_green_area
    FROM sustainability_metrics sm
    JOIN projects p ON sm.project_id = p.project_id
    GROUP BY p.project_name
    ORDER BY co2_saved_ton DESC
""")

print("\n🌱 Kontribusi Lingkungan per Proyek:")
for _, row in sustain_proj.head(5).iterrows():
    print(f"  {row['project_name'][:30]:<30} | CO2 saved: {row['co2_saved_ton']:>6.0f} ton | Renewable: {row['pct_renewable_energy']:>5.1f}%")

# 6.2 Tren bulanan sustainability
df_sustain['bulan'] = df_sustain['metric_date'].dt.to_period('M')
monthly_sustain = df_sustain.groupby('bulan').agg(
    total_co2_saved=('co2_saved_kg','sum'),
    total_solar=('solar_kwh','sum'),
    total_energy=('energy_kwh','sum'),
    avg_recycle=('recycled_waste_pct','mean')
).reset_index()
monthly_sustain['bulan'] = monthly_sustain['bulan'].astype(str)
monthly_sustain['renewable_pct'] = monthly_sustain['total_solar'] / monthly_sustain['total_energy'] * 100

fig, axes = plt.subplots(2, 2, figsize=(16, 10))

# CO2 savings trend
axes[0,0].fill_between(range(len(monthly_sustain)), monthly_sustain['total_co2_saved']/1000,
                        color='#4CAF50', alpha=0.7)
axes[0,0].plot(range(len(monthly_sustain)), monthly_sustain['total_co2_saved']/1000, 
               color='#1B5E20', linewidth=2)
axes[0,0].set_title('CO2 Saved per Bulan (Ton)', fontweight='bold')
axes[0,0].set_xticks(range(0, len(monthly_sustain), 4))
axes[0,0].set_xticklabels(monthly_sustain['bulan'].iloc[::4], rotation=45, ha='right')

# Renewable energy %
axes[0,1].plot(range(len(monthly_sustain)), monthly_sustain['renewable_pct'], 
               'o-', color='#FF9800', linewidth=2)
axes[0,1].axhline(y=30, color='red', linestyle='--', label='Target 30%')
axes[0,1].set_title('% Energi Terbarukan (Solar)', fontweight='bold')
axes[0,1].set_ylabel('Persentase (%)')
axes[0,1].legend()
axes[0,1].set_xticks(range(0, len(monthly_sustain), 4))
axes[0,1].set_xticklabels(monthly_sustain['bulan'].iloc[::4], rotation=45, ha='right')

# Recycling rate
axes[1,0].bar(range(len(monthly_sustain)), monthly_sustain['avg_recycle'],
              color=['#66BB6A' if v >= 60 else '#FFA726' for v in monthly_sustain['avg_recycle']])
axes[1,0].axhline(y=60, color='green', linestyle='--', label='Target 60%')
axes[1,0].set_title('Rata-rata Recycling Rate (%)', fontweight='bold')
axes[1,0].legend()
axes[1,0].set_xticks(range(0, len(monthly_sustain), 4))
axes[1,0].set_xticklabels(monthly_sustain['bulan'].iloc[::4], rotation=45, ha='right')

# Radar chart sustainability scores per project
categories = ['Renewable\nEnergy %', 'CO2 Saved', 'Recycle %', 'Green Area']
top5 = sustain_proj.head(5)
N = len(categories)
angles = [n / float(N) * 2 * np.pi for n in range(N)]
angles += angles[:1]

# Replace axes[1,1] with polar subplot
fig.delaxes(axes[1,1])
ax_polar = fig.add_subplot(2, 2, 4, polar=True)
ax_polar.set_theta_offset(np.pi / 2)
ax_polar.set_theta_direction(-1)
ax_polar.set_xticks(angles[:-1])
ax_polar.set_xticklabels(categories)
ax_polar.set_title('Sustainability Score\n(Top 5 Proyek)', fontweight='bold', pad=20)

for _, row in top5.iterrows():
    values = [
        row['pct_renewable_energy'],
        min(row['co2_saved_ton'] / 10 * 100, 100),
        row['avg_recycle_pct'],
        min(row['avg_green_area'] / 10000 * 100, 100)
    ]
    values += values[:1]
    name_short = ' '.join(row['project_name'].split()[-2:])
    ax_polar.plot(angles, values, linewidth=1.5, label=name_short)
    ax_polar.fill(angles, values, alpha=0.1)
ax_polar.legend(loc='upper right', bbox_to_anchor=(1.4, 1.15), fontsize=7)

plt.suptitle('Artha Properti - Sustainability Performance Dashboard', 
             fontsize=14, fontweight='bold', y=1.01)
plt.tight_layout()
plt.savefig('output/06_sustainability_dashboard.png', dpi=150, bbox_inches='tight')
plt.close()
print("  → Grafik disimpan: output/06_sustainability_dashboard.png")

# ============================================================
# MODUL 7: SALES PERFORMANCE & KPI DASHBOARD
# ============================================================

print("\n" + "="*60)
print("MODUL 7: SALES PERFORMANCE DASHBOARD")
print("="*60)

# 7.1 KPI Utama
total_rev = df_sales[df_sales['sale_status'].isin(['signed','paid'])]['net_price'].sum()
total_units_sold = len(df_sales[df_sales['sale_status'].isin(['signed','paid'])])
total_projects = df_proj.shape[0]
avg_discount = df_sales['discount_amount'].mean()

print(f"\n🎯 KPI Utama Artha Properti Sejahtera:")
print(f"  Total Revenue All Time : {format_rp(total_rev)}")
print(f"  Unit Terjual           : {total_units_sold:,} unit")
print(f"  Proyek Aktif           : {total_projects} proyek")
print(f"  Rata-rata Diskon       : {format_rp(avg_discount)}")

# 7.2 Top Sales Person
top_sales = query("""
    SELECT 
        e.full_name,
        COUNT(s.sale_id) AS unit_terjual,
        SUM(s.net_price) AS total_revenue,
        ROUND(AVG(s.net_price),0) AS avg_deal_size,
        MAX(s.net_price) AS biggest_deal
    FROM unit_sales s
    JOIN employees e ON s.sales_employee = e.employee_id
    WHERE s.sale_status IN ('signed','paid')
    GROUP BY e.full_name
    ORDER BY total_revenue DESC
    LIMIT 10
""")

print("\n🏆 Top 10 Sales Person:")
for i, (_, row) in enumerate(top_sales.iterrows(), 1):
    print(f"  {i:2}. {row['full_name']:<20} | {row['unit_terjual']:>3} unit | {format_rp(row['total_revenue']):>12}")

# 7.3 Payment Method Analysis
payment_analysis = query("""
    SELECT 
        payment_method,
        COUNT(*) AS jumlah_transaksi,
        SUM(net_price) AS total_nilai,
        ROUND(COUNT(*)*100.0/(SELECT COUNT(*) FROM unit_sales WHERE sale_status!='cancelled'),1) AS pct_transaksi
    FROM unit_sales
    WHERE sale_status != 'cancelled'
    GROUP BY payment_method
    ORDER BY jumlah_transaksi DESC
""")

# Final Dashboard Visual
fig, axes = plt.subplots(2, 2, figsize=(18, 12))
fig.suptitle('Artha Properti Sejahtera - Sales Performance Dashboard', 
             fontsize=16, fontweight='bold')

# Top sales
top5 = top_sales.head(5)
axes[0,0].barh([n.split()[-1] for n in top5['full_name']], top5['total_revenue']/1e9,
               color='#1565C0')
axes[0,0].set_xlabel('Revenue (Miliar Rp)')
axes[0,0].set_title('Top 5 Sales Person by Revenue', fontweight='bold')

# Payment method
axes[0,1].pie(payment_analysis['jumlah_transaksi'], labels=payment_analysis['payment_method'],
              autopct='%1.1f%%', colors=['#E3F2FD','#42A5F5','#1565C0','#0D47A1'])
axes[0,1].set_title('Metode Pembayaran', fontweight='bold')

# Monthly revenue by year
for year in ['2022', '2023', '2024']:
    monthly_yr = df_sales_valid[df_sales_valid['sale_date'].dt.year == int(year)]
    if len(monthly_yr) > 0:
        mr = monthly_yr.groupby(df_sales_valid['sale_date'].dt.month)['net_price'].sum()
        axes[1,0].plot(mr.index, mr.values/1e9, 'o-', label=year, linewidth=2, markersize=5)
axes[1,0].set_xlabel('Bulan')
axes[1,0].set_ylabel('Revenue (Miliar Rp)')
axes[1,0].set_title('Perbandingan Revenue Bulanan per Tahun', fontweight='bold')
axes[1,0].legend()
axes[1,0].set_xticks(range(1,13))
axes[1,0].set_xticklabels(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])

# Revenue by city/project type heatmap
pivot_data = query("""
    SELECT 
        p.project_type,
        strftime('%Y', s.sale_date) AS tahun,
        SUM(s.net_price)/1000000000.0 AS revenue_miliar
    FROM unit_sales s
    JOIN units u ON s.unit_id = u.unit_id
    JOIN projects p ON u.project_id = p.project_id
    WHERE s.sale_status IN ('signed','paid')
    GROUP BY p.project_type, tahun
""")
pivot_hm = pivot_data.pivot(index='project_type', columns='tahun', values='revenue_miliar').fillna(0)
sns.heatmap(pivot_hm, annot=True, fmt='.0f', cmap='YlOrRd', ax=axes[1,1])
axes[1,1].set_title('Revenue Heatmap (Miliar Rp)\nper Tipe & Tahun', fontweight='bold')

plt.tight_layout()
plt.savefig('output/07_sales_dashboard.png', dpi=150, bbox_inches='tight')
plt.close()
print("  → Grafik disimpan: output/07_sales_dashboard.png")

# ============================================================
# MODUL 8: ADVANCED - PRICE ANALYSIS & RECOMMENDATION
# ============================================================

print("\n" + "="*60)
print("MODUL 8: PRICE ANALYSIS & SIMPLE PREDICTION")
print("="*60)

# 8.1 Analisis diskon vs konversi
discount_analysis = query("""
    SELECT 
        CASE 
            WHEN discount_amount = 0 THEN 'Tanpa Diskon'
            WHEN discount_amount < 25000000 THEN '< 25jt'
            WHEN discount_amount < 50000000 THEN '25-50jt'
            ELSE '> 50jt'
        END AS kategori_diskon,
        COUNT(*) AS jumlah,
        SUM(CASE WHEN sale_status='paid' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS completion_rate
    FROM unit_sales
    GROUP BY kategori_diskon
    ORDER BY jumlah DESC
""")
print("\n💰 Efektifitas Diskon:")
print(discount_analysis.to_string(index=False))

# 8.2 Harga vs area (price per sqm analysis)
unit_price = query("""
    SELECT 
        p.project_type,
        u.unit_type,
        u.area_m2,
        u.current_price,
        ROUND(u.current_price / u.area_m2 / 1000000, 1) AS harga_per_m2_jt
    FROM units u
    JOIN projects p ON u.project_id = p.project_id
    WHERE u.status = 'available'
""")

price_by_type = unit_price.groupby(['project_type','unit_type'])['harga_per_m2_jt'].agg(['mean','min','max','count']).reset_index()
price_by_type.columns = ['project_type','unit_type','avg_price_m2','min_price_m2','max_price_m2','count']
print("\n📐 Harga per m² berdasarkan Tipe (Juta Rp):")
print(price_by_type[price_by_type['count']>=3].sort_values('avg_price_m2',ascending=False).head(10).to_string(index=False))

# ============================================================
# EXPORT LAPORAN EXCEL
# ============================================================

print("\n" + "="*60)
print("EXPORT: Membuat Laporan Excel")
print("="*60)

try:
    with pd.ExcelWriter('output/Laporan_Artha_Properti.xlsx', engine='openpyxl') as writer:
        # Sheet 1: Revenue per Proyek
        revenue_proj.to_excel(writer, sheet_name='Revenue per Proyek', index=False)
        
        # Sheet 2: Monthly Sales
        monthly_revenue.to_excel(writer, sheet_name='Tren Bulanan', index=False)
        
        # Sheet 3: Inventory
        inventory.to_excel(writer, sheet_name='Inventori Unit', index=False)
        
        # Sheet 4: Customer Segments
        seg_summary.to_excel(writer, sheet_name='Segmen Customer', index=False)
        
        # Sheet 5: Marketing ROI
        channel_perf.to_excel(writer, sheet_name='Marketing ROI', index=False)
        
        # Sheet 6: Sustainability
        sustain_proj.to_excel(writer, sheet_name='Sustainability', index=False)
        
        # Sheet 7: Top Sales
        top_sales.to_excel(writer, sheet_name='Top Sales', index=False)
    
    print("  ✅ Laporan Excel disimpan: output/Laporan_Artha_Properti.xlsx")
except Exception as e:
    print(f"  ⚠️  Export Excel: {e}")

# ============================================================
# PENUTUP
# ============================================================

conn.close()
print("\n" + "="*60)
print("✅ ANALISIS SELESAI!")
print("="*60)
print("\nFile Output yang Dihasilkan:")
print("  📊 output/01_revenue_per_proyek.png")
print("  📈 output/02_tren_penjualan_bulanan.png")
print("  📦 output/03_inventory_status.png")
print("  👥 output/04_customer_analysis.png")
print("  📣 output/05_marketing_performance.png")
print("  🌱 output/06_sustainability_dashboard.png")
print("  🏆 output/07_sales_dashboard.png")
print("  📋 output/Laporan_Artha_Properti.xlsx")
print("\nSelamat belajar Data Analysis! 🚀")
