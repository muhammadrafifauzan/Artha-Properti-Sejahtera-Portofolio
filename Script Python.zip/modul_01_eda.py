"""
================================================================
MODUL PYTHON 1: EKSPLORASI DATA (EDA)
Artha Properti Sejahtera - Data Analyst Learning Path
Level: Pemula | Estimasi: 2-3 Minggu
================================================================
TOPIK: pandas basics, data loading, .info(), .describe(), 
       missing values, data types, basic visualisasi
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import warnings
warnings.filterwarnings('ignore')

# Konfigurasi tampilan
pd.set_option('display.max_columns', 20)
pd.set_option('display.float_format', lambda x: f'{x:,.0f}')
plt.rcParams['figure.figsize'] = (12, 6)
plt.rcParams['font.size'] = 11

DATA_PATH = "./data/"  # Sesuaikan path jika perlu


# ================================================================
# BAGIAN 1: LOADING DATA
# ================================================================

print("=" * 60)
print("BAGIAN 1: LOADING DATA")
print("=" * 60)

# Load semua tabel
df_proyek    = pd.read_csv(f"{DATA_PATH}dim_proyek.csv")
df_unit      = pd.read_csv(f"{DATA_PATH}dim_unit.csv")
df_pelanggan = pd.read_csv(f"{DATA_PATH}dim_pelanggan.csv")
df_penjualan = pd.read_csv(f"{DATA_PATH}fact_penjualan.csv")
df_campaign  = pd.read_csv(f"{DATA_PATH}fact_marketing_campaign.csv")
df_konstruksi= pd.read_csv(f"{DATA_PATH}fact_konstruksi.csv")
df_sales_team= pd.read_csv(f"{DATA_PATH}dim_sales_team.csv")
df_keluhan   = pd.read_csv(f"{DATA_PATH}fact_keluhan_pelanggan.csv")
df_cicilan   = pd.read_csv(f"{DATA_PATH}fact_cicilan_pembayaran.csv")
df_green     = pd.read_csv(f"{DATA_PATH}dim_greenbuilding.csv")

print("✅ Semua data berhasil di-load!")
print("\nJumlah baris setiap tabel:")
tables = {
    'dim_proyek': df_proyek, 'dim_unit': df_unit,
    'dim_pelanggan': df_pelanggan, 'fact_penjualan': df_penjualan,
    'fact_marketing_campaign': df_campaign, 'fact_konstruksi': df_konstruksi,
    'dim_sales_team': df_sales_team, 'fact_keluhan_pelanggan': df_keluhan,
    'fact_cicilan_pembayaran': df_cicilan, 'dim_greenbuilding': df_green
}
for name, df in tables.items():
    print(f"  {name:35s}: {len(df):>6,} baris | {df.shape[1]} kolom")


# ================================================================
# BAGIAN 2: INSPEKSI DATA
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 2: INSPEKSI DATA - FACT_PENJUALAN")
print("=" * 60)

print("\n--- .head() ---")
print(df_penjualan.head())

print("\n--- .info() ---")
df_penjualan.info()

print("\n--- .describe() ---")
print(df_penjualan[['harga_listing','diskon_pct','harga_nett','dp_amount']].describe())

print("\n--- Shape ---")
print(f"Dimensi: {df_penjualan.shape[0]:,} baris × {df_penjualan.shape[1]} kolom")

print("\n--- Tipe Data ---")
print(df_penjualan.dtypes)


# ================================================================
# BAGIAN 3: MISSING VALUES
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 3: PENGECEKAN MISSING VALUES")
print("=" * 60)

def cek_missing(df, nama_tabel):
    missing = df.isnull().sum()
    pct = (missing / len(df) * 100).round(2)
    result = pd.DataFrame({'Missing': missing, 'Persen (%)': pct})
    result = result[result['Missing'] > 0]
    if len(result) > 0:
        print(f"\n{nama_tabel}:")
        print(result.to_string())
    else:
        print(f"\n{nama_tabel}: ✅ Tidak ada missing values")

for name, df in tables.items():
    cek_missing(df, name)


# ================================================================
# BAGIAN 4: KONVERSI TIPE DATA
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 4: KONVERSI TIPE DATA")
print("=" * 60)

# Konversi kolom tanggal
date_cols = {
    'df_penjualan': ['tanggal_sp', 'tanggal_akad'],
    'df_proyek': ['tanggal_mulai', 'tanggal_selesai'],
    'df_pelanggan': ['tanggal_lahir'],
}

df_penjualan['tanggal_sp']   = pd.to_datetime(df_penjualan['tanggal_sp'])
df_penjualan['tanggal_akad'] = pd.to_datetime(df_penjualan['tanggal_akad'])
df_proyek['tanggal_mulai']   = pd.to_datetime(df_proyek['tanggal_mulai'])
df_proyek['tanggal_selesai'] = pd.to_datetime(df_proyek['tanggal_selesai'])
df_keluhan['tanggal_masuk']  = pd.to_datetime(df_keluhan['tanggal_masuk'])

# Ekstrak fitur waktu
df_penjualan['tahun'] = df_penjualan['tanggal_sp'].dt.year
df_penjualan['bulan'] = df_penjualan['tanggal_sp'].dt.month
df_penjualan['kuartal'] = df_penjualan['tanggal_sp'].dt.quarter
df_penjualan['nama_bulan'] = df_penjualan['tanggal_sp'].dt.strftime('%b')

print("✅ Konversi tipe data selesai")
print(f"\nRentang data penjualan: {df_penjualan['tanggal_sp'].min().date()} "
      f"s/d {df_penjualan['tanggal_sp'].max().date()}")


# ================================================================
# BAGIAN 5: STATISTIK DESKRIPTIF PELANGGAN
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 5: PROFIL PELANGGAN")
print("=" * 60)

print("\nDistribusi Jenis Kelamin:")
print(df_pelanggan['jenis_kelamin'].value_counts())

print("\nTop 5 Pekerjaan:")
print(df_pelanggan['pekerjaan'].value_counts().head())

print("\nStatistik Penghasilan (Rp):")
print(df_pelanggan['penghasilan_bulanan'].describe())

print("\nTop 5 Sumber Leads:")
print(df_pelanggan['sumber_leads'].value_counts().head())


# ================================================================
# BAGIAN 6: VISUALISASI EDA DASAR
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 6: VISUALISASI EDA")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(18, 10))
fig.suptitle('Artha Properti Sejahtera - EDA Overview', fontsize=16, fontweight='bold')

# Plot 1: Distribusi tipe proyek
tipe_count = df_proyek['tipe_proyek'].value_counts()
axes[0, 0].pie(tipe_count.values, labels=tipe_count.index, autopct='%1.1f%%',
               colors=['#2ECC71', '#3498DB', '#E74C3C'])
axes[0, 0].set_title('Distribusi Tipe Proyek')

# Plot 2: Status unit
status_count = df_unit['status_unit'].value_counts()
colors = {'Terjual': '#27AE60', 'Tersedia': '#3498DB', 'Dipesan': '#F39C12'}
bars = axes[0, 1].bar(status_count.index, status_count.values,
                       color=[colors.get(s, '#95A5A6') for s in status_count.index])
axes[0, 1].set_title('Status Unit Keseluruhan')
axes[0, 1].set_ylabel('Jumlah Unit')
for bar, val in zip(bars, status_count.values):
    axes[0, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                    str(val), ha='center', va='bottom', fontweight='bold')

# Plot 3: Distribusi harga unit (histogram)
harga_miliar = df_unit['harga_jual'] / 1e9
axes[0, 2].hist(harga_miliar, bins=20, color='#3498DB', edgecolor='white', alpha=0.8)
axes[0, 2].set_title('Distribusi Harga Unit')
axes[0, 2].set_xlabel('Harga (Miliar Rp)')
axes[0, 2].set_ylabel('Jumlah Unit')

# Plot 4: Penjualan bulanan 2023
monthly = df_penjualan[df_penjualan['tahun'] == 2023].groupby('bulan')['harga_nett'].sum() / 1e9
axes[1, 0].plot(monthly.index, monthly.values, marker='o', color='#E74C3C', linewidth=2)
axes[1, 0].fill_between(monthly.index, monthly.values, alpha=0.3, color='#E74C3C')
axes[1, 0].set_title('Revenue Bulanan 2023 (Miliar Rp)')
axes[1, 0].set_xlabel('Bulan')
axes[1, 0].set_ylabel('Revenue (Miliar)')
axes[1, 0].set_xticks(range(1, 13))

# Plot 5: Revenue per proyek
rev_proyek = df_penjualan.merge(df_proyek[['proyek_id','nama_proyek']], on='proyek_id')
rev_proyek = rev_proyek.groupby('nama_proyek')['harga_nett'].sum().sort_values() / 1e9
axes[1, 1].barh(rev_proyek.index, rev_proyek.values, color='#9B59B6')
axes[1, 1].set_title('Total Revenue per Proyek (Miliar Rp)')
axes[1, 1].set_xlabel('Revenue (Miliar)')

# Plot 6: Sumber leads
leads = df_pelanggan['sumber_leads'].value_counts()
axes[1, 2].barh(leads.index, leads.values, color='#1ABC9C')
axes[1, 2].set_title('Distribusi Sumber Leads')
axes[1, 2].set_xlabel('Jumlah Pelanggan')

plt.tight_layout()
plt.savefig('./output_eda_overview.png', dpi=150, bbox_inches='tight')
plt.show()
print("✅ Chart EDA disimpan: output_eda_overview.png")


# ================================================================
# LATIHAN MANDIRI MODUL 1
# ================================================================
"""
LATIHAN:
1. Buat dataframe baru yang hanya berisi transaksi tahun 2022
2. Hitung berapa persen pelanggan yang beli dengan KPR vs KPA
3. Buat histogram distribusi umur pelanggan yang membeli
4. Cari nilai median harga unit per tipe_unit
5. Analisis: apakah ada korelasi antara luas_m2 dan harga_jual?
   Buat scatter plot-nya!

HINT:
- pd.crosstab() untuk tabel silang
- df.corr() untuk korelasi
- df.plot.scatter(x, y) untuk scatter plot
"""

print("\n✅ Modul 1 selesai! Lanjutkan ke modul_02_data_cleaning.py")
