"""
================================================================
MODUL PYTHON 2: DATA CLEANING & WRANGLING
Artha Properti Sejahtera - Data Analyst Learning Path
Level: Pemula-Menengah | Estimasi: 2 Minggu
================================================================
TOPIK: Handle missing values, duplicates, outliers, 
       merge/join, reshape, feature engineering
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings = lambda *a, **kw: None
import warnings; warnings.filterwarnings('ignore')

DATA_PATH = "./data/"

# Load data
df_penjualan = pd.read_csv(f"{DATA_PATH}fact_penjualan.csv", parse_dates=['tanggal_sp','tanggal_akad'])
df_unit      = pd.read_csv(f"{DATA_PATH}dim_unit.csv")
df_pelanggan = pd.read_csv(f"{DATA_PATH}dim_pelanggan.csv")
df_proyek    = pd.read_csv(f"{DATA_PATH}dim_proyek.csv")
df_cicilan   = pd.read_csv(f"{DATA_PATH}fact_cicilan_pembayaran.csv", parse_dates=['tanggal_jatuh_tempo','tanggal_bayar'])
df_keluhan   = pd.read_csv(f"{DATA_PATH}fact_keluhan_pelanggan.csv", parse_dates=['tanggal_masuk','tanggal_selesai'])

print("✅ Data loaded")


# ================================================================
# BAGIAN 1: MENANGANI MISSING VALUES
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 1: MISSING VALUES HANDLING")
print("=" * 60)

# Cek missing values
print("Missing values penjualan:")
print(df_penjualan.isnull().sum()[df_penjualan.isnull().sum() > 0])

# tanggal_akad null = belum akad (wajar)
# Kita isi dengan info teks, bukan drop
df_penjualan['status_akad'] = df_penjualan['tanggal_akad'].apply(
    lambda x: 'Sudah Akad' if pd.notna(x) else 'Belum Akad'
)

# Hitung hari dari SP ke akad
df_penjualan['hari_sp_ke_akad'] = (
    df_penjualan['tanggal_akad'] - df_penjualan['tanggal_sp']
).dt.days

print(f"\nRata-rata hari SP → Akad: {df_penjualan['hari_sp_ke_akad'].mean():.0f} hari")
print(f"Median hari SP → Akad: {df_penjualan['hari_sp_ke_akad'].median():.0f} hari")

# Missing di keluhan
print("\nMissing di keluhan:")
print(df_keluhan.isnull().sum()[df_keluhan.isnull().sum() > 0])

# Hitung resolusi time (hari)
df_keluhan['hari_resolusi'] = (
    df_keluhan['tanggal_selesai'] - df_keluhan['tanggal_masuk']
).dt.days


# ================================================================
# BAGIAN 2: DUPLIKAT
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 2: CEK & HAPUS DUPLIKAT")
print("=" * 60)

for name, df in [('penjualan', df_penjualan), ('unit', df_unit), ('pelanggan', df_pelanggan)]:
    dupes = df.duplicated().sum()
    print(f"  {name}: {dupes} duplikat ditemukan")

# Jika ada duplikat, cara hapus:
# df_penjualan = df_penjualan.drop_duplicates(subset=['penjualan_id'])


# ================================================================
# BAGIAN 3: OUTLIER DETECTION
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 3: DETEKSI OUTLIER")
print("=" * 60)

def detect_outliers_iqr(df, col):
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = df[(df[col] < lower) | (df[col] > upper)]
    print(f"  {col}: {len(outliers)} outlier | lower={lower:,.0f} | upper={upper:,.0f}")
    return outliers

detect_outliers_iqr(df_penjualan, 'harga_nett')
detect_outliers_iqr(df_pelanggan, 'penghasilan_bulanan')
detect_outliers_iqr(df_unit, 'harga_jual')

# Visualisasi outlier
fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle('Distribusi & Outlier Detection', fontsize=14)

df_penjualan['harga_nett'].plot.box(ax=axes[0], title='Harga Nett Penjualan')
df_pelanggan['penghasilan_bulanan'].plot.box(ax=axes[1], title='Penghasilan Bulanan Pelanggan')
df_unit['harga_jual'].plot.box(ax=axes[2], title='Harga Jual Unit')

plt.tight_layout()
plt.savefig('./output_outlier_detection.png', dpi=150, bbox_inches='tight')
plt.show()


# ================================================================
# BAGIAN 4: MERGE / JOIN TABEL
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 4: MERGE TABEL")
print("=" * 60)

# Master tabel penjualan lengkap
df_master = (
    df_penjualan
    .merge(df_proyek[['proyek_id','nama_proyek','tipe_proyek','kota','provinsi']], on='proyek_id', how='left')
    .merge(df_unit[['unit_id','tipe_unit','luas_m2','lantai','orientasi','furnished']], on='unit_id', how='left')
    .merge(df_pelanggan[['pelanggan_id','nama','jenis_kelamin','umur','kota_asal',
                          'pekerjaan','penghasilan_bulanan','sumber_leads','tipe_pembeli']], 
           on='pelanggan_id', how='left')
)

print(f"Master tabel: {df_master.shape}")
print(df_master.columns.tolist())


# ================================================================
# BAGIAN 5: FEATURE ENGINEERING
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 5: FEATURE ENGINEERING")
print("=" * 60)

# Fitur baru dari penjualan
df_master['tahun']          = df_master['tanggal_sp'].dt.year
df_master['bulan']          = df_master['tanggal_sp'].dt.month
df_master['kuartal']        = df_master['tanggal_sp'].dt.quarter
df_master['hari_dalam_minggu'] = df_master['tanggal_sp'].dt.day_name()

# Segmen harga
def segmen_harga(harga):
    if harga < 500_000_000:   return "< 500 Juta"
    elif harga < 1_000_000_000: return "500 Juta - 1 Miliar"
    elif harga < 2_000_000_000: return "1 - 2 Miliar"
    else:                        return "> 2 Miliar"

df_master['segmen_harga'] = df_master['harga_nett'].apply(segmen_harga)

# Segmen umur pembeli
def segmen_umur(umur):
    if umur < 30:   return "Muda (< 30)"
    elif umur < 40: return "Produktif (30-39)"
    elif umur < 50: return "Mapan (40-49)"
    else:           return "Senior (50+)"

df_master['segmen_umur'] = df_master['umur'].apply(segmen_umur)

# Efisiensi diskon
df_master['diskon_value'] = df_master['harga_listing'] - df_master['harga_nett']
df_master['dp_ratio']     = df_master['dp_amount'] / df_master['harga_nett']

print("Fitur baru yang dibuat:")
new_features = ['tahun','bulan','kuartal','hari_dalam_minggu','segmen_harga',
                'segmen_umur','diskon_value','dp_ratio','hari_sp_ke_akad']
for f in new_features:
    print(f"  ✅ {f}")

# ================================================================
# BAGIAN 6: RESHAPING DATA (PIVOT)
# ================================================================

print("\n" + "=" * 60)
print("BAGIAN 6: PIVOT TABLE & RESHAPING")
print("=" * 60)

# Pivot: Revenue per proyek per tahun
pivot_revenue = df_master.pivot_table(
    values='harga_nett',
    index='nama_proyek',
    columns='tahun',
    aggfunc='sum',
    fill_value=0
) / 1e9  # dalam miliar

pivot_revenue.columns = [f'Rev_{c}' for c in pivot_revenue.columns]
print("\nRevenue per Proyek per Tahun (Miliar Rp):")
print(pivot_revenue.round(1).to_string())

# Heatmap korelasi
fig, ax = plt.subplots(figsize=(10, 8))
numeric_cols = df_master.select_dtypes(include=[np.number]).columns.tolist()
corr_cols = ['harga_nett','harga_listing','luas_m2','umur',
             'penghasilan_bulanan','diskon_pct','dp_amount','dp_ratio']
corr_matrix = df_master[corr_cols].corr()

sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='RdYlGn',
            center=0, ax=ax, annot_kws={'size': 10})
ax.set_title('Korelasi Antar Variabel Numerik', fontsize=14)
plt.tight_layout()
plt.savefig('./output_correlation_heatmap.png', dpi=150, bbox_inches='tight')
plt.show()
print("✅ Heatmap disimpan")

# Simpan master dataset
df_master.to_csv('./data/master_penjualan.csv', index=False)
print("\n✅ Master dataset disimpan: data/master_penjualan.csv")


# ================================================================
# LATIHAN MANDIRI MODUL 2
# ================================================================
"""
LATIHAN:
1. Buat pivot table: jumlah unit terjual per tipe_unit per kuartal
2. Feature engineering baru: buat kolom 'kategori_dp' 
   (Tinggi: >25%, Sedang: 15-25%, Rendah: <15%)
3. Merge df_cicilan dengan df_penjualan, lalu hitung total denda 
   per pelanggan
4. Deteksi dan visualisasikan outlier pada kolom hari_resolusi 
   keluhan (setelah dihitung)
5. Buat crosstab: pekerjaan vs metode_pembayaran 
   (mana pekerjaan yang paling sering pakai KPR?)
"""

print("\n✅ Modul 2 selesai! Lanjutkan ke modul_03_analisis_bisnis.py")
