-- ================================================================
-- MODUL 4: WINDOW FUNCTIONS & ANALITIK LANJUTAN
-- Level: Menengah-Lanjut | Estimasi: 3 Minggu
-- ================================================================
-- TOPIK: ROW_NUMBER, RANK, DENSE_RANK, LAG, LEAD, RUNNING TOTAL,
--        CTE, SUBQUERY, PIVOT-like queries

-- ================================================================
-- LATIHAN 4.1 - WINDOW FUNCTIONS Ranking
-- ================================================================

-- Ranking sales berdasarkan revenue (dalam tim masing-masing)
SELECT 
    st.nama_sales,
    st.jabatan,
    st.tim,
    COUNT(p.penjualan_id)                           AS total_deal,
    SUM(p.harga_nett)                               AS total_revenue,
    RANK() OVER (ORDER BY SUM(p.harga_nett) DESC)   AS rank_overall,
    RANK() OVER (
        PARTITION BY st.tim 
        ORDER BY SUM(p.harga_nett) DESC
    )                                               AS rank_dalam_tim
FROM dim_sales_team st
LEFT JOIN fact_penjualan p ON st.sales_id = p.sales_id
GROUP BY st.sales_id, st.nama_sales, st.jabatan, st.tim
ORDER BY total_revenue DESC NULLS LAST;

-- Top 3 unit terlaris per proyek (DENSE_RANK)
WITH unit_sales AS (
    SELECT 
        p.proyek_id,
        u.tipe_unit,
        u.luas_m2,
        COUNT(*) AS jumlah_terjual,
        SUM(fp.harga_nett) AS total_nilai,
        DENSE_RANK() OVER (
            PARTITION BY p.proyek_id 
            ORDER BY COUNT(*) DESC
        ) AS rank_unit
    FROM fact_penjualan fp
    INNER JOIN dim_unit u ON fp.unit_id = u.unit_id
    INNER JOIN dim_proyek p ON fp.proyek_id = p.proyek_id
    GROUP BY p.proyek_id, u.tipe_unit, u.luas_m2
)
SELECT pr.nama_proyek, us.tipe_unit, us.jumlah_terjual, us.total_nilai, us.rank_unit
FROM unit_sales us
INNER JOIN dim_proyek pr ON us.proyek_id = pr.proyek_id
WHERE rank_unit <= 3
ORDER BY pr.nama_proyek, rank_unit;

-- ================================================================
-- LATIHAN 4.2 - LAG dan LEAD (Perbandingan Period)
-- ================================================================

-- Trend penjualan bulanan dengan perbandingan bulan sebelumnya
WITH monthly_sales AS (
    SELECT 
        DATE_TRUNC('month', tanggal_sp)    AS bulan,
        COUNT(*)                            AS unit_terjual,
        SUM(harga_nett)                     AS total_revenue
    FROM fact_penjualan
    WHERE status_transaksi != 'Batal'
    GROUP BY DATE_TRUNC('month', tanggal_sp)
)
SELECT 
    TO_CHAR(bulan, 'YYYY-MM')               AS periode,
    unit_terjual,
    total_revenue,
    LAG(unit_terjual) OVER (ORDER BY bulan) AS unit_bulan_lalu,
    unit_terjual - LAG(unit_terjual) OVER (ORDER BY bulan) AS selisih_unit,
    ROUND((total_revenue - LAG(total_revenue) OVER (ORDER BY bulan)) 
          * 100.0 / NULLIF(LAG(total_revenue) OVER (ORDER BY bulan), 0), 1) AS growth_pct
FROM monthly_sales
ORDER BY bulan;

-- ================================================================
-- LATIHAN 4.3 - Running Total & Cumulative
-- ================================================================

-- Akumulasi penjualan per tahun
WITH daily_sales AS (
    SELECT 
        tanggal_sp,
        SUM(harga_nett) AS daily_revenue
    FROM fact_penjualan
    WHERE EXTRACT(YEAR FROM tanggal_sp) = 2023
    GROUP BY tanggal_sp
)
SELECT 
    tanggal_sp,
    daily_revenue,
    SUM(daily_revenue) OVER (ORDER BY tanggal_sp)   AS cumulative_revenue,
    AVG(daily_revenue) OVER (
        ORDER BY tanggal_sp 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    )                                               AS moving_avg_7hari
FROM daily_sales
ORDER BY tanggal_sp;

-- ================================================================
-- LATIHAN 4.4 - CTE (Common Table Expressions)
-- ================================================================

-- Analisis lengkap: Revenue Proyek vs Target
WITH proyek_revenue AS (
    SELECT 
        proyek_id,
        SUM(harga_nett)     AS actual_revenue,
        COUNT(*)             AS unit_terjual
    FROM fact_penjualan
    WHERE status_transaksi = 'Selesai'
    GROUP BY proyek_id
),
proyek_target AS (
    SELECT 
        proyek_id,
        anggaran_total,
        total_unit,
        ROUND(anggaran_total * 1.3) AS target_revenue  -- target 130% dari anggaran
    FROM dim_proyek
)
SELECT 
    pr.nama_proyek,
    pr.tipe_proyek,
    pt.target_revenue,
    COALESCE(pvr.actual_revenue, 0)     AS actual_revenue,
    pt.total_unit,
    COALESCE(pvr.unit_terjual, 0)       AS unit_terjual,
    ROUND(COALESCE(pvr.unit_terjual, 0) * 100.0 / pt.total_unit, 1) AS pct_sold,
    CASE 
        WHEN COALESCE(pvr.actual_revenue, 0) >= pt.target_revenue THEN '✅ On Track'
        WHEN COALESCE(pvr.actual_revenue, 0) >= pt.target_revenue * 0.8 THEN '⚠️ Warning'
        ELSE '❌ Behind Target'
    END AS status_target
FROM dim_proyek pr
INNER JOIN proyek_target pt ON pr.proyek_id = pt.proyek_id
LEFT JOIN proyek_revenue pvr ON pr.proyek_id = pvr.proyek_id
ORDER BY pct_sold DESC;

-- ================================================================
-- LATIHAN 4.5 - Cohort Analysis Pelanggan
-- ================================================================

-- Cohort pembelian: kapan pelanggan pertama kali beli
WITH first_purchase AS (
    SELECT 
        pelanggan_id,
        MIN(tanggal_sp)         AS first_purchase_date,
        DATE_TRUNC('quarter', MIN(tanggal_sp)) AS cohort_quarter
    FROM fact_penjualan
    GROUP BY pelanggan_id
),
purchase_activity AS (
    SELECT 
        fp.cohort_quarter,
        COUNT(DISTINCT fp.pelanggan_id)     AS cohort_size,
        COUNT(p.penjualan_id)               AS total_transaksi,
        SUM(p.harga_nett)                   AS total_revenue
    FROM first_purchase fp
    LEFT JOIN fact_penjualan p ON fp.pelanggan_id = p.pelanggan_id
    GROUP BY fp.cohort_quarter
)
SELECT 
    TO_CHAR(cohort_quarter, 'YYYY-Q"Q"') AS cohort,
    cohort_size,
    total_transaksi,
    ROUND(total_transaksi * 1.0 / cohort_size, 2) AS transaksi_per_pelanggan,
    total_revenue / 1000000 AS revenue_juta
FROM purchase_activity
ORDER BY cohort_quarter;

-- ================================================================
-- LATIHAN 4.6 - ABC Analysis Unit (80/20 Rule)
-- ================================================================

WITH unit_revenue AS (
    SELECT 
        u.tipe_unit,
        COUNT(*)                AS total_terjual,
        SUM(p.harga_nett)       AS total_revenue
    FROM fact_penjualan p
    INNER JOIN dim_unit u ON p.unit_id = u.unit_id
    GROUP BY u.tipe_unit
),
ranked AS (
    SELECT 
        *,
        SUM(total_revenue) OVER ()                              AS grand_total,
        SUM(total_revenue) OVER (ORDER BY total_revenue DESC)   AS cumulative_revenue,
        ROUND(SUM(total_revenue) OVER (ORDER BY total_revenue DESC) 
              * 100.0 / SUM(total_revenue) OVER (), 1)          AS cumulative_pct
    FROM unit_revenue
)
SELECT 
    tipe_unit,
    total_terjual,
    total_revenue / 1000000     AS revenue_juta,
    cumulative_pct,
    CASE 
        WHEN cumulative_pct <= 80 THEN 'A - High Value (80%)'
        WHEN cumulative_pct <= 95 THEN 'B - Medium Value (15%)'
        ELSE 'C - Low Value (5%)'
    END AS abc_category
FROM ranked
ORDER BY total_revenue DESC;

-- ================================================================
-- LATIHAN 4.7 - Dashboard Query (Satu Query Komprehensif)
-- ================================================================

-- Executive Dashboard Summary
WITH summary AS (
    SELECT
        COUNT(DISTINCT CASE WHEN status = 'Berlangsung' THEN proyek_id END) AS proyek_aktif,
        COUNT(DISTINCT CASE WHEN status = 'Selesai' THEN proyek_id END) AS proyek_selesai,
        SUM(total_unit) AS total_unit_portfolio
    FROM dim_proyek
),
sales_summary AS (
    SELECT
        COUNT(*) AS total_transaksi,
        SUM(harga_nett) AS total_revenue,
        COUNT(DISTINCT pelanggan_id) AS total_pelanggan_aktif,
        AVG(harga_nett) AS avg_deal_size
    FROM fact_penjualan
    WHERE status_transaksi = 'Selesai'
      AND EXTRACT(YEAR FROM tanggal_sp) = 2023
),
unit_availability AS (
    SELECT
        COUNT(CASE WHEN status_unit = 'Tersedia' THEN 1 END) AS unit_tersedia,
        COUNT(CASE WHEN status_unit = 'Terjual' THEN 1 END) AS unit_terjual,
        COUNT(*) AS total_unit
    FROM dim_unit
),
complaint_summary AS (
    SELECT
        COUNT(*) AS total_keluhan_ytd,
        AVG(rating_kepuasan) AS avg_satisfaction,
        COUNT(CASE WHEN status = 'Eskalasi' THEN 1 END) AS keluhan_eskalasi
    FROM fact_keluhan_pelanggan
    WHERE EXTRACT(YEAR FROM tanggal_masuk) = 2023
)
SELECT 
    s.proyek_aktif,
    s.proyek_selesai,
    ss.total_transaksi,
    ROUND(ss.total_revenue / 1000000000, 2) AS revenue_miliar_2023,
    ss.total_pelanggan_aktif,
    ROUND(ss.avg_deal_size / 1000000, 1) AS avg_deal_juta,
    ua.unit_tersedia,
    ua.unit_terjual,
    ROUND(ua.unit_terjual * 100.0 / ua.total_unit, 1) AS sold_out_pct,
    cs.total_keluhan_ytd,
    ROUND(cs.avg_satisfaction, 2) AS avg_csat,
    cs.keluhan_eskalasi
FROM summary s, sales_summary ss, unit_availability ua, complaint_summary cs;

-- ================================================================
-- SOAL PRAKTEK MODUL 4
-- ================================================================
/*
1. Buat CTE untuk mencari 5 pelanggan dengan lifetime value tertinggi
2. Gunakan window function untuk menghitung market share penjualan 
   masing-masing proyek dalam portofolio total
3. Analisis: apakah cicilan yang terlambat lebih banyak di proyek 
   tertentu? Gunakan RANK() untuk mengurutkan
4. Buat query untuk mencari "sales terbaik bulan ini vs bulan lalu" 
   menggunakan LAG()
5. Implementasikan RFM (Recency, Frequency, Monetary) sederhana 
   untuk segmentasi pelanggan
*/
