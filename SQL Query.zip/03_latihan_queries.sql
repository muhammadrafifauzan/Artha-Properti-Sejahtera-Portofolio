-- ============================================================
-- ARTHA PROPERTI SEJAHTERA - LATIHAN SQL
-- Modul: Query dari Dasar hingga Advanced
-- ============================================================

-- ============================================================
-- TAHAP 1: DASAR SQL (Pemula)
-- ============================================================

-- 1.1 SELECT & WHERE: Lihat semua proyek aktif
SELECT project_id, project_name, project_type, city, status
FROM projects
WHERE status != 'planning'
ORDER BY city;

-- 1.2 LIKE: Cari proyek dengan nama mengandung kata "Green"
SELECT project_id, project_name, location
FROM projects
WHERE project_name LIKE '%Green%';

-- 1.3 IN: Filter unit berdasarkan beberapa tipe
SELECT unit_id, project_id, unit_type, area_m2, current_price, status
FROM units
WHERE unit_type IN ('Studio', '1BR', '2BR')
AND status = 'available'
ORDER BY current_price ASC;

-- 1.4 BETWEEN: Cari unit dengan harga antara 500 juta - 2 miliar
SELECT unit_id, project_id, unit_type, current_price, status
FROM units
WHERE current_price BETWEEN 500000000 AND 2000000000
AND status = 'available';

-- 1.5 COUNT: Berapa total unit per proyek?
SELECT project_id, COUNT(*) AS total_unit
FROM units
GROUP BY project_id
ORDER BY total_unit DESC;

-- ============================================================
-- TAHAP 2: AGGREGASI & GROUPING
-- ============================================================

-- 2.1 SUM: Total pendapatan dari penjualan per proyek
SELECT 
    p.project_name,
    COUNT(s.sale_id) AS total_transaksi,
    SUM(s.net_price) AS total_revenue,
    AVG(s.net_price) AS avg_harga_jual
FROM unit_sales s
JOIN units u ON s.unit_id = u.unit_id
JOIN projects p ON u.project_id = p.project_id
WHERE s.sale_status IN ('signed', 'paid')
GROUP BY p.project_name
ORDER BY total_revenue DESC;

-- 2.2 Performa Sales per Karyawan
SELECT 
    e.full_name AS nama_sales,
    COUNT(s.sale_id) AS total_penjualan,
    SUM(s.net_price) AS total_nilai,
    AVG(s.net_price) AS rata_rata_nilai,
    MAX(s.net_price) AS penjualan_tertinggi
FROM unit_sales s
JOIN employees e ON s.sales_employee = e.employee_id
WHERE s.sale_status IN ('signed', 'paid')
GROUP BY e.full_name
HAVING COUNT(s.sale_id) > 5
ORDER BY total_nilai DESC
LIMIT 10;

-- 2.3 Tren Penjualan per Bulan (2022-2024)
SELECT 
    strftime('%Y', sale_date) AS tahun,
    strftime('%m', sale_date) AS bulan,
    COUNT(*) AS jumlah_unit_terjual,
    SUM(net_price) AS total_revenue
FROM unit_sales
WHERE sale_status IN ('signed', 'paid')
GROUP BY tahun, bulan
ORDER BY tahun, bulan;

-- 2.4 Distribusi Metode Pembayaran
SELECT 
    payment_method,
    COUNT(*) AS jumlah,
    SUM(net_price) AS total_nilai,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM unit_sales WHERE sale_status != 'cancelled'), 2) AS pct
FROM unit_sales
WHERE sale_status != 'cancelled'
GROUP BY payment_method
ORDER BY jumlah DESC;

-- 2.5 Status Unit per Proyek (Inventory Report)
SELECT 
    p.project_name,
    p.project_type,
    COUNT(CASE WHEN u.status = 'available' THEN 1 END) AS available,
    COUNT(CASE WHEN u.status = 'booked' THEN 1 END) AS booked,
    COUNT(CASE WHEN u.status = 'sold' THEN 1 END) AS sold,
    COUNT(*) AS total,
    ROUND(COUNT(CASE WHEN u.status = 'sold' THEN 1 END) * 100.0 / COUNT(*), 1) AS pct_sold
FROM units u
JOIN projects p ON u.project_id = p.project_id
GROUP BY p.project_name, p.project_type
ORDER BY pct_sold DESC;

-- ============================================================
-- TAHAP 3: JOIN KOMPLEKS
-- ============================================================

-- 3.1 Detail Transaksi Lengkap (Multi-table JOIN)
SELECT 
    s.sale_id,
    c.full_name AS nama_pembeli,
    c.occupation AS pekerjaan,
    p.project_name AS nama_proyek,
    u.unit_type AS tipe_unit,
    u.area_m2 AS luas,
    s.sale_date AS tanggal_beli,
    s.net_price AS harga_beli,
    s.payment_method AS cara_bayar,
    e.full_name AS nama_sales,
    s.sale_status AS status
FROM unit_sales s
JOIN customers c ON s.customer_id = c.customer_id
JOIN units u ON s.unit_id = u.unit_id
JOIN projects p ON u.project_id = p.project_id
JOIN employees e ON s.sales_employee = e.employee_id
ORDER BY s.sale_date DESC
LIMIT 20;

-- 3.2 Customer Lifetime Value (CLV) - Pelanggan dengan multiple pembelian
SELECT 
    c.customer_id,
    c.full_name,
    c.occupation,
    c.customer_type,
    COUNT(s.sale_id) AS jumlah_pembelian,
    SUM(s.net_price) AS total_nilai_pembelian,
    MIN(s.sale_date) AS pertama_beli,
    MAX(s.sale_date) AS terakhir_beli
FROM customers c
JOIN unit_sales s ON c.customer_id = s.customer_id
WHERE s.sale_status IN ('signed', 'paid')
GROUP BY c.customer_id, c.full_name, c.occupation, c.customer_type
HAVING COUNT(s.sale_id) > 1
ORDER BY total_nilai_pembelian DESC;

-- 3.3 Marketing ROI per Campaign
SELECT 
    mc.campaign_name,
    mc.channel,
    p.project_name,
    mc.budget,
    mc.actual_spend,
    mc.actual_leads,
    mc.conversions,
    ROUND(mc.actual_spend / NULLIF(mc.actual_leads, 0), 0) AS cost_per_lead,
    ROUND(mc.actual_spend / NULLIF(mc.conversions, 0), 0) AS cost_per_conversion,
    ROUND(mc.conversions * 100.0 / NULLIF(mc.actual_leads, 0), 2) AS conversion_rate_pct
FROM marketing_campaigns mc
JOIN projects p ON mc.project_id = p.project_id
ORDER BY conversion_rate_pct DESC;

-- 3.4 Lead Funnel Analysis
SELECT 
    lead_status,
    COUNT(*) AS jumlah_lead,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM marketing_leads), 2) AS persen
FROM marketing_leads
GROUP BY lead_status
ORDER BY jumlah_lead DESC;

-- ============================================================
-- TAHAP 4: WINDOW FUNCTIONS (Advanced)
-- ============================================================

-- 4.1 RANK: Peringkat sales berdasarkan pendapatan bulanan
SELECT 
    e.full_name,
    strftime('%Y-%m', s.sale_date) AS bulan,
    COUNT(*) AS unit_terjual,
    SUM(s.net_price) AS revenue,
    RANK() OVER (
        PARTITION BY strftime('%Y-%m', s.sale_date) 
        ORDER BY SUM(s.net_price) DESC
    ) AS rank_bulan
FROM unit_sales s
JOIN employees e ON s.sales_employee = e.employee_id
WHERE s.sale_status IN ('signed', 'paid')
GROUP BY e.full_name, bulan;

-- 4.2 RUNNING TOTAL: Akumulasi pendapatan per tahun
SELECT 
    sale_date,
    net_price AS revenue_hari,
    SUM(net_price) OVER (
        PARTITION BY strftime('%Y', sale_date)
        ORDER BY sale_date
        ROWS UNBOUNDED PRECEDING
    ) AS running_total_revenue
FROM unit_sales
WHERE sale_status IN ('signed', 'paid')
ORDER BY sale_date;

-- 4.3 LAG/LEAD: Perbandingan penjualan bulan ini vs bulan lalu
WITH monthly_sales AS (
    SELECT 
        strftime('%Y-%m', sale_date) AS bulan,
        COUNT(*) AS unit_terjual,
        SUM(net_price) AS total_revenue
    FROM unit_sales
    WHERE sale_status IN ('signed', 'paid')
    GROUP BY bulan
)
SELECT 
    bulan,
    total_revenue,
    LAG(total_revenue) OVER (ORDER BY bulan) AS revenue_bulan_lalu,
    ROUND((total_revenue - LAG(total_revenue) OVER (ORDER BY bulan)) * 100.0 / 
          NULLIF(LAG(total_revenue) OVER (ORDER BY bulan), 0), 2) AS growth_pct
FROM monthly_sales
ORDER BY bulan;

-- 4.4 NTILE: Segmentasi customer berdasarkan nilai pembelian
WITH customer_value AS (
    SELECT 
        c.customer_id,
        c.full_name,
        SUM(s.net_price) AS total_purchase
    FROM customers c
    JOIN unit_sales s ON c.customer_id = s.customer_id
    WHERE s.sale_status IN ('signed', 'paid')
    GROUP BY c.customer_id, c.full_name
)
SELECT 
    customer_id,
    full_name,
    total_purchase,
    NTILE(4) OVER (ORDER BY total_purchase DESC) AS kuartil,
    CASE NTILE(4) OVER (ORDER BY total_purchase DESC)
        WHEN 1 THEN 'Premium (Top 25%)'
        WHEN 2 THEN 'Gold (25-50%)'
        WHEN 3 THEN 'Silver (50-75%)'
        WHEN 4 THEN 'Basic (75-100%)'
    END AS segmen
FROM customer_value
ORDER BY total_purchase DESC;

-- ============================================================
-- TAHAP 5: STUDI KASUS BISNIS NYATA
-- ============================================================

-- 5.1 KASUS: Dashboard Eksekutif - KPI Summary
SELECT 
    'Total Revenue YTD' AS kpi,
    printf("Rp %.0f", SUM(net_price)) AS nilai
FROM unit_sales 
WHERE strftime('%Y', sale_date) = '2023' AND sale_status IN ('signed','paid')
UNION ALL
SELECT 'Unit Terjual YTD', CAST(COUNT(*) AS TEXT)
FROM unit_sales 
WHERE strftime('%Y', sale_date) = '2023' AND sale_status IN ('signed','paid')
UNION ALL
SELECT 'Total Unit Available', CAST(COUNT(*) AS TEXT)
FROM units WHERE status = 'available'
UNION ALL
SELECT 'Conversion Rate', printf("%.1f%%", COUNT(*)*100.0/(SELECT COUNT(*) FROM marketing_leads))
FROM unit_sales WHERE sale_status IN ('signed','paid');

-- 5.2 KASUS: Deteksi Unit yang Terlalu Lama Tidak Terjual (>180 hari)
SELECT 
    u.unit_id,
    p.project_name,
    u.unit_type,
    u.current_price,
    u.status,
    CAST(julianday('now') - julianday('2024-01-01') AS INT) AS hari_belum_terjual
FROM units u
JOIN projects p ON u.project_id = p.project_id
WHERE u.status = 'available'
AND p.status = 'ready'
ORDER BY hari_belum_terjual DESC
LIMIT 20;

-- 5.3 KASUS: Cohort Analysis - Retention Booking ke Pembayaran
SELECT 
    payment_method,
    sale_status,
    COUNT(*) AS jumlah,
    ROUND(AVG(julianday(contract_date) - julianday(sale_date)), 0) AS avg_hari_booking_ke_kontrak
FROM unit_sales
WHERE contract_date IS NOT NULL AND contract_date != ''
GROUP BY payment_method, sale_status;

-- 5.4 KASUS: Sustainability Report per Proyek
SELECT 
    p.project_name,
    p.project_type,
    ROUND(AVG(sm.energy_kwh), 0) AS avg_energy_kwh,
    ROUND(AVG(sm.solar_kwh), 0) AS avg_solar_kwh,
    ROUND(AVG(sm.solar_kwh / NULLIF(sm.energy_kwh, 0)) * 100, 1) AS pct_renewable,
    ROUND(SUM(sm.co2_saved_kg), 0) AS total_co2_saved_kg,
    ROUND(AVG(sm.recycled_waste_pct), 1) AS avg_recycle_pct,
    ROUND(AVG(sm.green_area_m2), 0) AS avg_green_area_m2
FROM sustainability_metrics sm
JOIN projects p ON sm.project_id = p.project_id
GROUP BY p.project_name, p.project_type
ORDER BY total_co2_saved_kg DESC;

-- 5.5 KASUS: Revenue Forecasting Basis (3-bulan rata-rata bergerak)
WITH monthly AS (
    SELECT 
        strftime('%Y-%m', sale_date) AS bulan,
        SUM(net_price) AS revenue
    FROM unit_sales
    WHERE sale_status IN ('signed','paid')
    GROUP BY bulan
)
SELECT 
    bulan,
    revenue,
    ROUND(AVG(revenue) OVER (
        ORDER BY bulan 
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ), 0) AS moving_avg_3m
FROM monthly
ORDER BY bulan;

COMMIT;
