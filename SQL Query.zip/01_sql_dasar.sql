-- ================================================================
-- MODUL 1: SQL DASAR - ARTHA PROPERTI SEJAHTERA
-- Level: Pemula | Estimasi: 2-3 Minggu
-- ================================================================
-- TOPIK: SELECT, WHERE, ORDER BY, LIMIT, DISTINCT, Alias

-- ================================================================
-- LATIHAN 1.1 - SELECT Dasar
-- ================================================================

-- Tampilkan semua proyek Artha Properti
SELECT * FROM dim_proyek;

-- Tampilkan hanya kolom penting proyek
SELECT proyek_id, nama_proyek, tipe_proyek, kota, status
FROM dim_proyek;

-- ================================================================
-- LATIHAN 1.2 - Alias kolom & tabel
-- ================================================================

-- Gunakan alias agar lebih mudah dibaca
SELECT 
    proyek_id           AS "ID Proyek",
    nama_proyek         AS "Nama Proyek",
    tipe_proyek         AS "Tipe",
    anggaran_total / 1000000  AS "Anggaran (Juta Rp)"
FROM dim_proyek AS p;

-- ================================================================
-- LATIHAN 1.3 - WHERE dengan kondisi tunggal
-- ================================================================

-- Proyek apartemen saja
SELECT nama_proyek, kota, total_unit
FROM dim_proyek
WHERE tipe_proyek = 'Apartemen';

-- Unit dengan harga di atas 1 Milyar
SELECT unit_id, proyek_id, tipe_unit, harga_jual
FROM dim_unit
WHERE harga_jual > 1000000000;

-- Proyek yang sudah selesai
SELECT nama_proyek, tipe_proyek, tanggal_selesai
FROM dim_proyek
WHERE status = 'Selesai';

-- ================================================================
-- LATIHAN 1.4 - WHERE dengan kondisi majemuk (AND, OR, NOT)
-- ================================================================

-- Unit Terjual di proyek tertentu
SELECT unit_id, tipe_unit, harga_jual, status_unit
FROM dim_unit
WHERE proyek_id = 'PRJ002'
  AND status_unit = 'Terjual';

-- Perumahan atau Apartemen di Jawa Barat
SELECT nama_proyek, tipe_proyek, kota
FROM dim_proyek
WHERE (tipe_proyek = 'Perumahan' OR tipe_proyek = 'Apartemen')
  AND provinsi = 'Jawa Barat';

-- Pelanggan yang bukan Karyawan Swasta
SELECT nama, pekerjaan, penghasilan_bulanan
FROM dim_pelanggan
WHERE NOT pekerjaan = 'Karyawan Swasta'
LIMIT 20;

-- ================================================================
-- LATIHAN 1.5 - BETWEEN, IN, LIKE, IS NULL
-- ================================================================

-- Harga unit antara 500 juta s/d 1 Milyar
SELECT unit_id, tipe_unit, harga_jual
FROM dim_unit
WHERE harga_jual BETWEEN 500000000 AND 1000000000;

-- Proyek di kota-kota tertentu
SELECT nama_proyek, kota, tipe_proyek
FROM dim_proyek
WHERE kota IN ('Jakarta Selatan','Bekasi Timur','Depok');

-- Cari pelanggan dengan nama mengandung 'Budi'
SELECT pelanggan_id, nama, no_telepon
FROM dim_pelanggan
WHERE nama LIKE '%Budi%';

-- Penjualan yang belum ada tanggal akad (NULL)
SELECT penjualan_id, unit_id, tanggal_sp, tanggal_akad
FROM fact_penjualan
WHERE tanggal_akad IS NULL
LIMIT 10;

-- ================================================================
-- LATIHAN 1.6 - ORDER BY
-- ================================================================

-- Unit termahal 10 besar
SELECT unit_id, proyek_id, tipe_unit, harga_jual
FROM dim_unit
ORDER BY harga_jual DESC
LIMIT 10;

-- Pelanggan termuda
SELECT nama, umur, pekerjaan, penghasilan_bulanan
FROM dim_pelanggan
ORDER BY umur ASC
LIMIT 10;

-- Penjualan terbaru
SELECT penjualan_id, proyek_id, harga_nett, tanggal_sp
FROM fact_penjualan
ORDER BY tanggal_sp DESC
LIMIT 15;

-- ================================================================
-- LATIHAN 1.7 - DISTINCT
-- ================================================================

-- Kota-kota tempat proyek berada
SELECT DISTINCT kota, provinsi
FROM dim_proyek
ORDER BY provinsi, kota;

-- Metode pembayaran yang tersedia
SELECT DISTINCT metode_pembayaran
FROM fact_penjualan;

-- Sumber leads pelanggan
SELECT DISTINCT sumber_leads
FROM dim_pelanggan
ORDER BY sumber_leads;

-- ================================================================
-- SOAL PRAKTEK MODUL 1
-- ================================================================
/*
1. Tampilkan semua unit yang 'Tersedia' dengan luas > 60 m2
2. Cari pelanggan perempuan (jenis_kelamin = 'P') dari Jakarta
3. Tampilkan 5 penjualan dengan nilai harga_nett tertinggi
4. Berapa banyak proyek yang masih 'Berlangsung'?
5. Tampilkan unit-unit di proyek PRJ003 yang sudah 'Terjual', 
   diurutkan dari harga tertinggi
*/
