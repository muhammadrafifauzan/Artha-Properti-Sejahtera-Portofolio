-- ================================================================
-- MODUL 3: JOIN ANTAR TABEL - ARTHA PROPERTI SEJAHTERA
-- Level: Menengah | Estimasi: 2-3 Minggu
-- ================================================================
-- TOPIK: INNER JOIN, LEFT JOIN, RIGHT JOIN, FULL JOIN, SELF JOIN

-- ================================================================
-- LATIHAN 3.1 - INNER JOIN (data yang cocok di kedua tabel)
-- ================================================================

-- Data penjualan lengkap dengan info proyek
SELECT 
    p.penjualan_id,
    pr.nama_proyek,
    pr.tipe_proyek,
    pr.kota,
    p.harga_nett,
    p.metode_pembayaran,
    p.tanggal_sp
FROM fact_penjualan p
INNER JOIN dim_proyek pr ON p.proyek_id = pr.proyek_id
WHERE p.status_transaksi = 'Selesai'
ORDER BY p.tanggal_sp DESC
LIMIT 20;

-- Penjualan lengkap dengan info pelanggan
SELECT 
    p.penjualan_id,
    pl.nama,
    pl.pekerjaan,
    pl.sumber_leads,
    pr.nama_proyek,
    u.tipe_unit,
    u.luas_m2,
    p.harga_nett,
    p.tanggal_sp
FROM fact_penjualan p
INNER JOIN dim_pelanggan pl ON p.pelanggan_id = pl.pelanggan_id
INNER JOIN dim_proyek pr    ON p.proyek_id = pr.proyek_id
INNER JOIN dim_unit u       ON p.unit_id = u.unit_id
ORDER BY p.tanggal_sp DESC
LIMIT 20;

-- ================================================================
-- LATIHAN 3.2 - LEFT JOIN (semua dari kiri, cocok dari kanan)
-- ================================================================

-- Semua proyek + total penjualan (termasuk proyek tanpa penjualan)
SELECT 
    pr.proyek_id,
    pr.nama_proyek,
    pr.tipe_proyek,
    pr.status,
    COUNT(p.penjualan_id)   AS jumlah_penjualan,
    COALESCE(SUM(p.harga_nett), 0) AS total_revenue
FROM dim_proyek pr
LEFT JOIN fact_penjualan p ON pr.proyek_id = p.proyek_id
GROUP BY pr.proyek_id, pr.nama_proyek, pr.tipe_proyek, pr.status
ORDER BY total_revenue DESC;

-- Semua pelanggan + berapa unit yang dibeli
SELECT 
    pl.pelanggan_id,
    pl.nama,
    pl.kota_asal,
    pl.sumber_leads,
    COUNT(p.penjualan_id)   AS jumlah_pembelian,
    COALESCE(SUM(p.harga_nett), 0) AS total_belanja
FROM dim_pelanggan pl
LEFT JOIN fact_penjualan p ON pl.pelanggan_id = p.pelanggan_id
GROUP BY pl.pelanggan_id, pl.nama, pl.kota_asal, pl.sumber_leads
ORDER BY jumlah_pembelian DESC
LIMIT 20;

-- ================================================================
-- LATIHAN 3.3 - Analisis Sales Performance
-- ================================================================

-- Performa setiap sales
SELECT 
    st.sales_id,
    st.nama_sales,
    st.jabatan,
    st.tim,
    pr.nama_proyek AS proyek_fokus,
    COUNT(p.penjualan_id)           AS total_deal,
    SUM(p.harga_nett)               AS total_revenue,
    AVG(p.harga_nett)               AS avg_deal_size,
    MAX(p.harga_nett)               AS deal_terbesar
FROM dim_sales_team st
LEFT JOIN fact_penjualan p  ON st.sales_id = p.sales_id
LEFT JOIN dim_proyek pr     ON st.proyek_fokus = pr.proyek_id
GROUP BY st.sales_id, st.nama_sales, st.jabatan, st.tim, pr.nama_proyek
ORDER BY total_revenue DESC NULLS LAST;

-- ================================================================
-- LATIHAN 3.4 - JOIN dengan Subquery
-- ================================================================

-- Pelanggan yang membeli lebih dari 1 unit (repeat buyer)
SELECT 
    pl.nama,
    pl.pekerjaan,
    pl.penghasilan_bulanan,
    beli.jumlah_unit,
    beli.total_investasi
FROM dim_pelanggan pl
INNER JOIN (
    SELECT 
        pelanggan_id,
        COUNT(*)        AS jumlah_unit,
        SUM(harga_nett) AS total_investasi
    FROM fact_penjualan
    WHERE status_transaksi = 'Selesai'
    GROUP BY pelanggan_id
    HAVING COUNT(*) > 1
) beli ON pl.pelanggan_id = beli.pelanggan_id
ORDER BY beli.jumlah_unit DESC;

-- ================================================================
-- LATIHAN 3.5 - JOIN untuk Analisis Marketing
-- ================================================================

-- Efektivitas campaign per proyek
SELECT 
    pr.nama_proyek,
    pr.tipe_proyek,
    mc.channel,
    SUM(mc.pengeluaran)                                         AS total_spend,
    SUM(mc.leads)                                               AS total_leads,
    SUM(mc.konversi)                                            AS total_konversi,
    ROUND(SUM(mc.konversi)*100.0/NULLIF(SUM(mc.leads),0), 2)   AS ctr_pct,
    ROUND(SUM(mc.pengeluaran)/NULLIF(SUM(mc.konversi),0))       AS cost_per_sale
FROM fact_marketing_campaign mc
INNER JOIN dim_proyek pr ON mc.proyek_id = pr.proyek_id
GROUP BY pr.nama_proyek, pr.tipe_proyek, mc.channel
ORDER BY ctr_pct DESC NULLS LAST;

-- ================================================================
-- LATIHAN 3.6 - Analisis Keluhan + Green Building
-- ================================================================

-- Keluhan per proyek dengan info green building
SELECT 
    pr.nama_proyek,
    pr.tipe_proyek,
    gb.level_sertifikasi,
    COUNT(k.keluhan_id)                                         AS total_keluhan,
    AVG(k.rating_kepuasan)                                      AS avg_rating,
    SUM(CASE WHEN k.prioritas = 'Kritis' THEN 1 ELSE 0 END)    AS keluhan_kritis
FROM dim_proyek pr
LEFT JOIN fact_keluhan_pelanggan k  ON pr.proyek_id = k.proyek_id
LEFT JOIN dim_greenbuilding gb      ON pr.proyek_id = gb.proyek_id
GROUP BY pr.nama_proyek, pr.tipe_proyek, gb.level_sertifikasi
ORDER BY total_keluhan DESC;

-- ================================================================
-- LATIHAN 3.7 - Analisis Cicilan & Keterlambatan
-- ================================================================

-- Analisis cicilan + info unit & proyek
SELECT 
    pr.nama_proyek,
    u.tipe_unit,
    COUNT(c.cicilan_id)                                                 AS total_cicilan,
    SUM(CASE WHEN c.ketepatan_bayar = 'Terlambat' THEN 1 ELSE 0 END)   AS terlambat,
    ROUND(SUM(CASE WHEN c.ketepatan_bayar = 'Terlambat' THEN 1.0 ELSE 0 END) 
          * 100 / COUNT(c.cicilan_id), 1)                               AS pct_terlambat,
    SUM(c.denda)                                                        AS total_denda
FROM fact_cicilan_pembayaran c
INNER JOIN fact_penjualan p ON c.penjualan_id = p.penjualan_id
INNER JOIN dim_unit u       ON p.unit_id = u.unit_id
INNER JOIN dim_proyek pr    ON p.proyek_id = pr.proyek_id
GROUP BY pr.nama_proyek, u.tipe_unit
ORDER BY pct_terlambat DESC;

-- ================================================================
-- SOAL PRAKTEK MODUL 3
-- ================================================================
/*
1. Tampilkan nama pelanggan, nama proyek, tipe unit, dan harga untuk 
   semua penjualan KPR di tahun 2022
2. Hitung performa tiap Tim (Tim A/B/C): total deal, total revenue, avg deal size
3. Proyek mana yang sertifikasi green-nya paling tinggi dan bagaimana 
   korelasi dengan keluhan pelanggan?
4. Buat laporan: nama sales, proyek fokus, jumlah deal, 
   total revenue, rata-rata diskon yang diberikan
5. Pelanggan dari kota mana yang paling banyak membeli unit apartemen?
*/
