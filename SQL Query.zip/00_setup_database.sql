-- ================================================================
-- ARTHA PROPERTI SEJAHTERA - DATABASE SETUP
-- File: 00_setup_database.sql
-- Deskripsi: DDL lengkap untuk membuat semua tabel
-- ================================================================

-- Buat database (jalankan sekali)
-- CREATE DATABASE artha_properti;
-- USE artha_properti;

-- ================================================================
-- TABEL DIMENSI
-- ================================================================

-- 1. Dimensi Proyek
CREATE TABLE IF NOT EXISTS dim_proyek (
    proyek_id       VARCHAR(10) PRIMARY KEY,
    nama_proyek     VARCHAR(100) NOT NULL,
    tipe_proyek     VARCHAR(20) CHECK (tipe_proyek IN ('Perumahan','Apartemen','Komersial')),
    kota            VARCHAR(50),
    provinsi        VARCHAR(50),
    total_unit      INT,
    tanggal_mulai   DATE,
    tanggal_selesai DATE,
    status          VARCHAR(20),
    anggaran_total  BIGINT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Dimensi Unit
CREATE TABLE IF NOT EXISTS dim_unit (
    unit_id         VARCHAR(10) PRIMARY KEY,
    proyek_id       VARCHAR(10) REFERENCES dim_proyek(proyek_id),
    tipe_unit       VARCHAR(30),
    luas_m2         DECIMAL(8,2),
    lantai          INT,
    harga_jual      BIGINT,
    status_unit     VARCHAR(20) CHECK (status_unit IN ('Tersedia','Terjual','Dipesan')),
    orientasi       VARCHAR(10),
    parkir          VARCHAR(5),
    furnished       VARCHAR(5)
);

-- 3. Dimensi Pelanggan
CREATE TABLE IF NOT EXISTS dim_pelanggan (
    pelanggan_id        VARCHAR(10) PRIMARY KEY,
    nama                VARCHAR(100),
    jenis_kelamin       CHAR(1),
    tanggal_lahir       DATE,
    umur                INT,
    kota_asal           VARCHAR(50),
    no_telepon          VARCHAR(20),
    email               VARCHAR(100),
    pekerjaan           VARCHAR(50),
    penghasilan_bulanan BIGINT,
    tipe_pembeli        VARCHAR(20),
    sumber_leads        VARCHAR(30)
);

-- 4. Dimensi Sales Team
CREATE TABLE IF NOT EXISTS dim_sales_team (
    sales_id            VARCHAR(10) PRIMARY KEY,
    nama_sales          VARCHAR(100),
    jabatan             VARCHAR(50),
    tim                 VARCHAR(10),
    tanggal_bergabung   DATE,
    gaji_pokok          INT,
    proyek_fokus        VARCHAR(10)
);

-- 5. Dimensi Green Building
CREATE TABLE IF NOT EXISTS dim_greenbuilding (
    sertifikat_id           VARCHAR(10) PRIMARY KEY,
    proyek_id               VARCHAR(10) REFERENCES dim_proyek(proyek_id),
    lembaga_sertifikasi     VARCHAR(30),
    level_sertifikasi       VARCHAR(20),
    tanggal_sertifikasi     DATE,
    penghematan_energi_pct  DECIMAL(5,2),
    penghematan_air_pct     DECIMAL(5,2),
    pengurangan_karbon_pct  DECIMAL(5,2),
    fitur_hijau             TEXT
);

-- ================================================================
-- TABEL FAKTA
-- ================================================================

-- 6. Fakta Penjualan
CREATE TABLE IF NOT EXISTS fact_penjualan (
    penjualan_id        VARCHAR(10) PRIMARY KEY,
    unit_id             VARCHAR(10) REFERENCES dim_unit(unit_id),
    proyek_id           VARCHAR(10) REFERENCES dim_proyek(proyek_id),
    pelanggan_id        VARCHAR(10) REFERENCES dim_pelanggan(pelanggan_id),
    sales_id            VARCHAR(10) REFERENCES dim_sales_team(sales_id),
    tanggal_sp          DATE,
    tanggal_akad        DATE,
    metode_pembayaran   VARCHAR(30),
    harga_listing       BIGINT,
    diskon_pct          DECIMAL(5,2),
    harga_nett          BIGINT,
    dp_amount           BIGINT,
    status_pembayaran   VARCHAR(30),
    status_transaksi    VARCHAR(20)
);

-- 7. Fakta Marketing Campaign
CREATE TABLE IF NOT EXISTS fact_marketing_campaign (
    campaign_id     VARCHAR(10) PRIMARY KEY,
    nama_campaign   VARCHAR(150),
    channel         VARCHAR(50),
    proyek_id       VARCHAR(10) REFERENCES dim_proyek(proyek_id),
    tanggal_mulai   DATE,
    tanggal_akhir   DATE,
    budget          BIGINT,
    pengeluaran     BIGINT,
    impressi        INT,
    klik            INT,
    leads           INT,
    konversi        INT
);

-- 8. Fakta Konstruksi
CREATE TABLE IF NOT EXISTS fact_konstruksi (
    konstruksi_id       VARCHAR(10) PRIMARY KEY,
    proyek_id           VARCHAR(10) REFERENCES dim_proyek(proyek_id),
    tahapan             VARCHAR(60),
    tanggal_plan        DATE,
    tanggal_aktual      DATE,
    progress_plan_pct   INT,
    progress_aktual_pct INT,
    biaya_plan          BIGINT,
    biaya_aktual        BIGINT,
    status_tahapan      VARCHAR(30)
);

-- 9. Fakta Keluhan Pelanggan
CREATE TABLE IF NOT EXISTS fact_keluhan_pelanggan (
    keluhan_id          VARCHAR(10) PRIMARY KEY,
    pelanggan_id        VARCHAR(10) REFERENCES dim_pelanggan(pelanggan_id),
    proyek_id           VARCHAR(10) REFERENCES dim_proyek(proyek_id),
    kategori            VARCHAR(50),
    prioritas           VARCHAR(10),
    tanggal_masuk       DATE,
    tanggal_selesai     DATE,
    status              VARCHAR(20),
    rating_kepuasan     INT,
    channel_keluhan     VARCHAR(30)
);

-- 10. Fakta Cicilan Pembayaran
CREATE TABLE IF NOT EXISTS fact_cicilan_pembayaran (
    cicilan_id          VARCHAR(10) PRIMARY KEY,
    penjualan_id        VARCHAR(10) REFERENCES fact_penjualan(penjualan_id),
    unit_id             VARCHAR(10),
    ke_bulan            INT,
    tanggal_jatuh_tempo DATE,
    tanggal_bayar       DATE,
    jumlah_angsuran     BIGINT,
    denda               INT,
    ketepatan_bayar     VARCHAR(20),
    status_bayar        VARCHAR(20)
);

-- ================================================================
-- INDEX untuk performa query
-- ================================================================
CREATE INDEX idx_penjualan_proyek    ON fact_penjualan(proyek_id);
CREATE INDEX idx_penjualan_tanggal   ON fact_penjualan(tanggal_sp);
CREATE INDEX idx_penjualan_sales     ON fact_penjualan(sales_id);
CREATE INDEX idx_unit_proyek         ON dim_unit(proyek_id);
CREATE INDEX idx_keluhan_proyek      ON fact_keluhan_pelanggan(proyek_id);
CREATE INDEX idx_cicilan_penjualan   ON fact_cicilan_pembayaran(penjualan_id);
CREATE INDEX idx_campaign_proyek     ON fact_marketing_campaign(proyek_id);

SELECT 'Database setup selesai!' AS info;
