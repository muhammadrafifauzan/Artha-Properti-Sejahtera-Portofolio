-- ============================================================
-- ARTHA PROPERTI SEJAHTERA - DATABASE SCHEMA
-- ============================================================
-- Perusahaan Developer Property Ramah Lingkungan
-- Segmen: Apartemen, Perumahan, Area Komersial
-- ============================================================

-- Drop tables if exists (untuk fresh install)
DROP TABLE IF EXISTS marketing_leads;
DROP TABLE IF EXISTS sustainability_metrics;
DROP TABLE IF EXISTS payment_transactions;
DROP TABLE IF EXISTS unit_sales;
DROP TABLE IF EXISTS units;
DROP TABLE IF EXISTS projects;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS marketing_campaigns;
DROP TABLE IF EXISTS green_certifications;

-- ============================================================
-- TABEL KARYAWAN
-- ============================================================
CREATE TABLE employees (
    employee_id     VARCHAR(10) PRIMARY KEY,
    full_name       VARCHAR(100) NOT NULL,
    department      VARCHAR(50) NOT NULL,
    position        VARCHAR(80) NOT NULL,
    hire_date       DATE NOT NULL,
    salary          DECIMAL(15,2) NOT NULL,
    email           VARCHAR(100),
    phone           VARCHAR(20),
    is_active       BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- TABEL PROYEK
-- ============================================================
CREATE TABLE projects (
    project_id      VARCHAR(10) PRIMARY KEY,
    project_name    VARCHAR(150) NOT NULL,
    project_type    VARCHAR(30) NOT NULL,   -- 'apartemen','perumahan','komersial'
    location        VARCHAR(100) NOT NULL,
    city            VARCHAR(50) NOT NULL,
    total_units     INT NOT NULL,
    land_area_m2    DECIMAL(12,2),
    start_date      DATE NOT NULL,
    est_completion  DATE,
    status          VARCHAR(30) NOT NULL,   -- 'planning','construction','ready','sold_out'
    green_concept   VARCHAR(200),
    project_manager VARCHAR(10) REFERENCES employees(employee_id),
    total_investment DECIMAL(18,2)
);

-- ============================================================
-- TABEL UNIT PROPERTI
-- ============================================================
CREATE TABLE units (
    unit_id         VARCHAR(15) PRIMARY KEY,
    project_id      VARCHAR(10) REFERENCES projects(project_id),
    unit_type       VARCHAR(50) NOT NULL,   -- 'studio','1BR','2BR','3BR','ruko','kios'
    unit_number     VARCHAR(20) NOT NULL,
    floor_number    INT,
    area_m2         DECIMAL(8,2) NOT NULL,
    base_price      DECIMAL(15,2) NOT NULL,
    current_price   DECIMAL(15,2) NOT NULL,
    status          VARCHAR(20) NOT NULL,   -- 'available','booked','sold','reserved'
    view_type       VARCHAR(30),            -- 'city','garden','pool','street'
    facilities      TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABEL CUSTOMERS
-- ============================================================
CREATE TABLE customers (
    customer_id     VARCHAR(10) PRIMARY KEY,
    full_name       VARCHAR(100) NOT NULL,
    email           VARCHAR(100),
    phone           VARCHAR(20),
    id_number       VARCHAR(20),            -- KTP
    address         TEXT,
    city            VARCHAR(50),
    occupation      VARCHAR(80),
    monthly_income  DECIMAL(15,2),
    customer_type   VARCHAR(20),            -- 'end_user','investor','kpr'
    acquisition_source VARCHAR(30),        -- 'website','referral','agent','expo','sosmed'
    registration_date DATE,
    is_active       BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- TABEL PENJUALAN UNIT
-- ============================================================
CREATE TABLE unit_sales (
    sale_id         VARCHAR(15) PRIMARY KEY,
    unit_id         VARCHAR(15) REFERENCES units(unit_id),
    customer_id     VARCHAR(10) REFERENCES customers(customer_id),
    sales_employee  VARCHAR(10) REFERENCES employees(employee_id),
    sale_date       DATE NOT NULL,
    sale_price      DECIMAL(15,2) NOT NULL,
    discount_amount DECIMAL(15,2) DEFAULT 0,
    net_price       DECIMAL(15,2) NOT NULL,
    payment_method  VARCHAR(20) NOT NULL,   -- 'cash','kpr','kpa','installment'
    bank_partner    VARCHAR(50),
    contract_date   DATE,
    handover_date   DATE,
    sale_status     VARCHAR(20) NOT NULL    -- 'booking','signed','paid','cancelled'
);

-- ============================================================
-- TABEL TRANSAKSI PEMBAYARAN
-- ============================================================
CREATE TABLE payment_transactions (
    transaction_id  VARCHAR(15) PRIMARY KEY,
    sale_id         VARCHAR(15) REFERENCES unit_sales(sale_id),
    customer_id     VARCHAR(10) REFERENCES customers(customer_id),
    payment_date    DATE NOT NULL,
    amount          DECIMAL(15,2) NOT NULL,
    payment_type    VARCHAR(30) NOT NULL,   -- 'booking_fee','dp','installment','kpr_disbursement'
    payment_method  VARCHAR(30),
    bank_name       VARCHAR(50),
    reference_no    VARCHAR(50),
    status          VARCHAR(20) DEFAULT 'completed'
);

-- ============================================================
-- TABEL MARKETING CAMPAIGNS
-- ============================================================
CREATE TABLE marketing_campaigns (
    campaign_id     VARCHAR(10) PRIMARY KEY,
    campaign_name   VARCHAR(150) NOT NULL,
    project_id      VARCHAR(10) REFERENCES projects(project_id),
    channel         VARCHAR(30) NOT NULL,   -- 'digital','print','event','referral','agent'
    start_date      DATE NOT NULL,
    end_date        DATE,
    budget          DECIMAL(15,2) NOT NULL,
    actual_spend    DECIMAL(15,2),
    target_leads    INT,
    actual_leads    INT DEFAULT 0,
    conversions     INT DEFAULT 0,
    campaign_status VARCHAR(20) DEFAULT 'active'
);

-- ============================================================
-- TABEL MARKETING LEADS
-- ============================================================
CREATE TABLE marketing_leads (
    lead_id         VARCHAR(15) PRIMARY KEY,
    campaign_id     VARCHAR(10) REFERENCES marketing_campaigns(campaign_id),
    customer_id     VARCHAR(10) REFERENCES customers(customer_id),
    lead_date       DATE NOT NULL,
    lead_source     VARCHAR(30),
    project_interest VARCHAR(10) REFERENCES projects(project_id),
    unit_type_interest VARCHAR(30),
    budget_range    VARCHAR(30),
    follow_up_count INT DEFAULT 0,
    lead_status     VARCHAR(20),            -- 'new','contacted','interested','hot','converted','dead'
    assigned_to     VARCHAR(10) REFERENCES employees(employee_id),
    notes           TEXT
);

-- ============================================================
-- TABEL SERTIFIKASI HIJAU
-- ============================================================
CREATE TABLE green_certifications (
    cert_id         VARCHAR(10) PRIMARY KEY,
    project_id      VARCHAR(10) REFERENCES projects(project_id),
    cert_type       VARCHAR(50),            -- 'GREENSHIP','LEED','ISO14001','SNI'
    cert_level      VARCHAR(20),            -- 'bronze','silver','gold','platinum'
    issuing_body    VARCHAR(100),
    issue_date      DATE,
    expiry_date     DATE,
    score           DECIMAL(5,2),
    is_active       BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- TABEL SUSTAINABILITY METRICS
-- ============================================================
CREATE TABLE sustainability_metrics (
    metric_id       VARCHAR(15) PRIMARY KEY,
    project_id      VARCHAR(10) REFERENCES projects(project_id),
    metric_date     DATE NOT NULL,
    energy_kwh      DECIMAL(12,2),          -- Konsumsi energi
    water_m3        DECIMAL(12,2),          -- Konsumsi air
    waste_kg        DECIMAL(12,2),          -- Limbah
    solar_kwh       DECIMAL(12,2),          -- Energi solar dihasilkan
    green_area_m2   DECIMAL(10,2),          -- Luas area hijau
    co2_saved_kg    DECIMAL(12,2),          -- CO2 yang dihemat
    recycled_waste_pct DECIMAL(5,2)         -- % sampah didaur ulang
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_units_project ON units(project_id);
CREATE INDEX idx_units_status ON units(status);
CREATE INDEX idx_sales_date ON unit_sales(sale_date);
CREATE INDEX idx_sales_customer ON unit_sales(customer_id);
CREATE INDEX idx_payment_sale ON payment_transactions(sale_id);
CREATE INDEX idx_payment_date ON payment_transactions(payment_date);
CREATE INDEX idx_leads_campaign ON marketing_leads(campaign_id);
CREATE INDEX idx_leads_status ON marketing_leads(lead_status);

COMMIT;

SELECT 'Schema berhasil dibuat!' AS status;
