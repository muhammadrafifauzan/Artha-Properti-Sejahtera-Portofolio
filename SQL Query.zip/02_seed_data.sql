-- ============================================================
-- ARTHA PROPERTI SEJAHTERA - DATA SEEDING SCRIPT
-- ============================================================
-- Jalankan setelah 01_schema.sql
-- Gunakan: sqlite3 artha_properti.db < 02_seed_data.sql
-- ============================================================

-- Import data dari CSV (SQLite syntax)
-- Untuk PostgreSQL, gunakan COPY FROM atau \copy

.mode csv
.import --skip 1 data/employees.csv employees
.import --skip 1 data/projects.csv projects
.import --skip 1 data/units.csv units
.import --skip 1 data/customers.csv customers
.import --skip 1 data/unit_sales.csv unit_sales
.import --skip 1 data/payment_transactions.csv payment_transactions
.import --skip 1 data/marketing_campaigns.csv marketing_campaigns
.import --skip 1 data/marketing_leads.csv marketing_leads
.import --skip 1 data/green_certifications.csv green_certifications
.import --skip 1 data/sustainability_metrics.csv sustainability_metrics

.mode column
.headers on

SELECT 'employees' as tabel, COUNT(*) as jumlah FROM employees
UNION ALL SELECT 'projects', COUNT(*) FROM projects
UNION ALL SELECT 'units', COUNT(*) FROM units
UNION ALL SELECT 'customers', COUNT(*) FROM customers
UNION ALL SELECT 'unit_sales', COUNT(*) FROM unit_sales
UNION ALL SELECT 'payment_transactions', COUNT(*) FROM payment_transactions
UNION ALL SELECT 'marketing_campaigns', COUNT(*) FROM marketing_campaigns
UNION ALL SELECT 'marketing_leads', COUNT(*) FROM marketing_leads
UNION ALL SELECT 'green_certifications', COUNT(*) FROM green_certifications
UNION ALL SELECT 'sustainability_metrics', COUNT(*) FROM sustainability_metrics;

SELECT '✅ Data berhasil di-import!' AS status;
