-- ================================================================
-- MODUL 2: AGREGASI & GROUP BY - ARTHA PROPERTI SEJAHTERA
-- Level: Pemula-Menengah | Estimasi: 2 Minggu
-- ================================================================
-- TOPIK: COUNT, SUM, AVG, MIN, MAX, GROUP BY, HAVING

-- ================================================================
-- LATIHAN 2.1 - Fungsi Agregat Dasar
-- ================================================================

-- Total unit keseluruhan
SELECT COUNT(*) AS total_unit FROM dim_unit;

-- Total nilai penjualan
SELECT 
    SUM(harga_nett)              AS total_pendapatan,
    COUNT(*)                      AS jumlah_transaksi,
    AVG(harga_nett)              AS rata_harga,
    MIN(harga_nett)              AS harga_terendah,
    MAX(harga_nett)              AS harga_tertinggi
FROM fact_penjualan
WHERE status_transaksi = 'Selesai';

-- ================================================================
-- LATIHAN 2.2 - GROUP BY Satu Kolom
-- ================================================================

-- Jumlah unit per proyek
SELECT 
    proyek_id,
    COUNT(*)           AS jumlah_unit,
    SUM(CASE WHEN status_unit = 'Terjual' THEN 1 ELSE 0 END) AS unit_terjual,
    SUM(CASE WHEN status_unit = 'Tersedia' THEN 1 ELSE 0 END) AS unit_tersedia
FROM dim_unit
GROUP BY proyek_id
ORDER BY jumlah_unit DESC;

-- Total penjualan per proyek
SELECT 
    proyek_id,
    COUNT(*)                    AS jumlah_transaksi,
    SUM(harga_nett)             AS total_pendapatan,
    ROUND(AVG(harga_nett))      AS avg_harga
FROM fact_penjualan
GROUP BY proyek_id
ORDER BY total_pendapatan DESC;

-- Distribusi metode pembayaran
SELECT 
    metode_pembayaran,
    COUNT(*)                                            AS jumlah,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 1) AS persentase
FROM fact_penjualan
GROUP BY metode_pembayaran
ORDER BY jumlah DESC;

-- ================================================================
-- LATIHAN 2.3 - GROUP BY Multi Kolom
-- ================================================================

-- Penjualan per proyek per tahun
SELECT 
    proyek_id,
    EXTRACT(YEAR FROM tanggal_sp)   AS tahun,
    COUNT(*)                         AS jumlah_unit_terjual,
    SUM(harga_nett)                  AS total_penjualan
FROM fact_penjualan
GROUP BY proyek_id, EXTRACT(YEAR FROM tanggal_sp)
ORDER BY proyek_id, tahun;

-- Distribusi unit berdasarkan tipe dan status
SELECT 
    tipe_unit,
    status_unit,
    COUNT(*)                    AS jumlah,
    AVG(harga_jual)             AS avg_harga,
    SUM(harga_jual)             AS total_nilai
FROM dim_unit
GROUP BY tipe_unit, status_unit
ORDER BY tipe_unit, status_unit;

-- ================================================================
-- LATIHAN 2.4 - HAVING (filter setelah GROUP BY)
-- ================================================================

-- Proyek dengan total penjualan > 5 Milyar
SELECT 
    proyek_id,
    COUNT(*)            AS jumlah_transaksi,
    SUM(harga_nett)     AS total_penjualan
FROM fact_penjualan
GROUP BY proyek_id
HAVING SUM(harga_nett) > 5000000000
ORDER BY total_penjualan DESC;

-- Tipe unit yang rata-rata harganya > 800 juta
SELECT 
    tipe_unit,
    COUNT(*)            AS jumlah_unit,
    AVG(harga_jual)     AS avg_harga
FROM dim_unit
GROUP BY tipe_unit
HAVING AVG(harga_jual) > 800000000
ORDER BY avg_harga DESC;

-- Sales dengan lebih dari 30 transaksi
SELECT 
    sales_id,
    COUNT(*)        AS jumlah_penjualan,
    SUM(harga_nett) AS total_revenue
FROM fact_penjualan
GROUP BY sales_id
HAVING COUNT(*) > 30
ORDER BY jumlah_penjualan DESC;

-- ================================================================
-- LATIHAN 2.5 - Analisis Waktu dengan GROUP BY
-- ================================================================

-- Trend penjualan bulanan 2023
SELECT 
    EXTRACT(MONTH FROM tanggal_sp) AS bulan,
    TO_CHAR(tanggal_sp, 'Month')   AS nama_bulan,
    COUNT(*)                        AS unit_terjual,
    SUM(harga_nett)                 AS total_penjualan
FROM fact_penjualan
WHERE EXTRACT(YEAR FROM tanggal_sp) = 2023
GROUP BY EXTRACT(MONTH FROM tanggal_sp), TO_CHAR(tanggal_sp, 'Month')
ORDER BY bulan;

-- Performa penjualan Q1-Q4 per tahun
SELECT 
    EXTRACT(YEAR FROM tanggal_sp)           AS tahun,
    EXTRACT(QUARTER FROM tanggal_sp)        AS kuartal,
    COUNT(*)                                AS transaksi,
    SUM(harga_nett)/1000000                 AS total_juta
FROM fact_penjualan
GROUP BY 
    EXTRACT(YEAR FROM tanggal_sp),
    EXTRACT(QUARTER FROM tanggal_sp)
ORDER BY tahun, kuartal;

-- ================================================================
-- LATIHAN 2.6 - CASE WHEN dalam Agregasi (Analisis Lanjutan)
-- ================================================================

-- Segmentasi pelanggan berdasarkan penghasilan
SELECT 
    CASE 
        WHEN penghasilan_bulanan < 10000000  THEN '< 10 Juta'
        WHEN penghasilan_bulanan < 20000000  THEN '10-20 Juta'
        WHEN penghasilan_bulanan < 40000000  THEN '20-40 Juta'
        ELSE '> 40 Juta'
    END AS segmen_penghasilan,
    COUNT(*) AS jumlah_pelanggan,
    ROUND(AVG(penghasilan_bulanan)/1000000, 1) AS avg_penghasilan_juta
FROM dim_pelanggan
GROUP BY 
    CASE 
        WHEN penghasilan_bulanan < 10000000  THEN '< 10 Juta'
        WHEN penghasilan_bulanan < 20000000  THEN '10-20 Juta'
        WHEN penghasilan_bulanan < 40000000  THEN '20-40 Juta'
        ELSE '> 40 Juta'
    END
ORDER BY MIN(penghasilan_bulanan);

-- Analisis efektivitas campaign
SELECT
    channel,
    COUNT(*)                                    AS jumlah_campaign,
    SUM(pengeluaran)                            AS total_biaya,
    SUM(leads)                                  AS total_leads,
    SUM(konversi)                               AS total_konversi,
    ROUND(SUM(konversi)*100.0/NULLIF(SUM(leads),0), 2) AS conversion_rate_pct,
    ROUND(SUM(pengeluaran)*1.0/NULLIF(SUM(konversi),0)) AS cost_per_conversion
FROM fact_marketing_campaign
GROUP BY channel
ORDER BY conversion_rate_pct DESC;

-- ================================================================
-- SOAL PRAKTEK MODUL 2
-- ================================================================
/*
1. Berapa rata-rata harga unit per tipe_proyek? (join dengan dim_unit & dim_proyek)
2. Proyek mana yang memiliki keluhan terbanyak?
3. Hitung total denda cicilan per bulan di tahun 2023
4. Tampilkan 3 sumber_leads yang menghasilkan pembeli terbanyak
5. Berapa persen unit yang sudah 'Terjual' vs 'Tersedia' per proyek?
*/
